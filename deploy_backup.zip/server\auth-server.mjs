import { handlePklRoutes } from "./routes/pkl.mjs";
import { handleHikvisionRoutes } from "./routes/hikvision.mjs";
import { handleKedisiplinanRoutes } from "./routes/kedisiplinan.mjs";
import { handleDataRoutes } from "./routes/data.mjs";
import { handleAuthRoutes } from "./routes/auth.mjs";
import { handleSettingsRoutes } from "./routes/settings.mjs";
import { createServer } from "node:http";
import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import pg from "pg";
import cron from "node-cron";
import { google } from "googleapis";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { buildAllowedOrigins, resolveCorsOrigin } from "./cors.mjs";
import { normalizeAdminUser, normalizeTeachers, verifyPassword } from "../src/utils/auth.js";
import { HikvisionAPI, decryptPassword, encryptPassword } from "./hikvision-api.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = resolve(__dirname, "..");
const storeDir = resolve(rootDir, "data");

const loadEnvFile = () => {
  const envFile = resolve(rootDir, ".env");
  try {
    const raw = readFileSync(envFile, "utf8");
    raw.split(/\r?\n/).forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) return;
      const separatorIndex = trimmed.indexOf("=");
      if (separatorIndex <= 0) return;
      const key = trimmed.slice(0, separatorIndex).trim();
      let value = trimmed.slice(separatorIndex + 1).trim();
      if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      if (!Object.prototype.hasOwnProperty.call(process.env, key)) {
        process.env[key] = value;
      }
    });
  } catch {
    // .env is optional; defaults below still support the usual Laragon setup.
  }
};

loadEnvFile();

let dbPool;
let dbStatus = {
  ok: false,
  code: "DB_NOT_INITIALIZED",
  message: "Database PostgreSQL belum tersambung.",
};
const DB_CONFIG = {
  host: process.env.PG_HOST || "127.0.0.1",
  port: parseInt(process.env.PG_PORT || "5432", 10),
  user: process.env.PG_USER || "postgres",
  password: process.env.PG_PASSWORD || "",
  database: process.env.PG_DATABASE || "school_system_db",
};

async function syncAllUsersToModules() {
  if (!dbPool) return;
  try {
    const { rows: mstRows } = await dbPool.query('SELECT payload FROM mst_students');
    const students = mstRows.map(r => r.payload);
    
    // Sync to PKL
    const activeNisSet = new Set();
    for (const s of students) {
      if (!s.nis) continue;
      activeNisSet.add(String(s.nis));
      await dbPool.query(`
        INSERT INTO pkl_students (nis, status)
        VALUES ($1, 'aktif')
        ON CONFLICT (nis) DO UPDATE SET status = 'aktif'
      `, [s.nis]);
    }
    // Mark missing as tidak_aktif
    if (activeNisSet.size > 0) {
      const { rows: pklRows } = await dbPool.query("SELECT nis FROM pkl_students WHERE status = 'aktif'");
      for (const row of pklRows) {
        if (!activeNisSet.has(String(row.nis))) {
          await dbPool.query("UPDATE pkl_students SET status = 'tidak_aktif' WHERE nis = $1", [row.nis]);
        }
      }
    }

    // Sync to Hikvision DB Mapping
    for (const s of students) {
      if (!s.nis) continue;
      await dbPool.query(`
        INSERT INTO hikvision_students (nis, name, class_name)
        VALUES ($1, $2, $3)
        ON CONFLICT (nis) DO UPDATE SET name = EXCLUDED.name, class_name = EXCLUDED.class_name
      `, [s.nis, s.name, s.class_name]);
    }

    // Guru Sync
    const { rows: tRows } = await dbPool.query('SELECT payload FROM mst_teachers');
    const teachers = tRows.map(r => r.payload);
    for (const t of teachers) {
      if (!t.code) continue;
      await dbPool.query(`
        INSERT INTO hikvision_teachers (teacher_code, name)
        VALUES ($1, $2)
        ON CONFLICT (teacher_code) DO UPDATE SET name = EXCLUDED.name
      `, [t.code, t.name]);
    }

    // Karyawan Sync
    const { rows: stRows } = await dbPool.query('SELECT payload FROM mst_staffs');
    const staffs = stRows.map(r => r.payload);
    for (const st of staffs) {
      if (!st.code) continue;
      await dbPool.query(`
        INSERT INTO hikvision_staffs (staff_code, name)
        VALUES ($1, $2)
        ON CONFLICT (staff_code) DO UPDATE SET name = EXCLUDED.name
      `, [st.code, st.name]);
    }
    
    // Sync to physical Hikvision Devices
    const { rows: devices } = await dbPool.query("SELECT * FROM hikvision_devices");
    for (const device of devices) {
      const plainPassword = decryptPassword(device.encrypted_password, device.iv_vector);
      const api = new HikvisionAPI(device.ip_address, device.username, plainPassword);
      const existingUsers = await api.getUsers();
      const existingIds = new Set(existingUsers.map(u => String(u.employeeNo)));
      
      for (const s of students) {
        if (!s.nis) continue;
        if (!existingIds.has(String(s.nis))) await api.createUser(s.nis, s.name);
      }
      for (const t of teachers) {
        if (!t.code) continue;
        if (!existingIds.has(String(t.code))) await api.createUser(t.code, t.name);
      }
      for (const st of staffs) {
        if (!st.code) continue;
        if (!existingIds.has(String(st.code))) await api.createUser(st.code, st.name);
      }
    }
    console.log("Background sync to PKL and Hikvision finished successfully.");
  } catch (err) {
    console.error("Error in syncAllUsersToModules:", err);
  }
}

async function pullHikvisionLogs() {
  if (!dbPool) return { logs_found: 0, logs_saved: 0 };
  const config = await getHikvisionConfig();
  let totalSaved = 0;
  let totalFound = 0;
  try {
    const { rows: devices } = await dbPool.query("SELECT * FROM hikvision_devices");
    for (const device of devices) {
      try {
        const plainPassword = decryptPassword(device.encrypted_password, device.iv_vector);
        const api = new HikvisionAPI(device.ip_address, device.username, plainPassword);
        const logs = await api.getLogs();
        totalFound += logs.length;
        
        for (const log of logs) {
          const employeeNo = log.employeeNoString;
          if (!employeeNo) continue;
          const eventType = `${log.major}-${log.minor}`;
          const logTime = log.time.replace('T', ' ').split(/[+-Z]/)[0];
          
          const existing = await dbPool.query(
            "SELECT 1 FROM hikvision_logs WHERE device_id = $1 AND employee_id = $2 AND timestamp = $3 AND event_type = $4",
            [device.id, employeeNo, logTime, eventType]
          );
          
          if (existing.rowCount === 0) {
            let personType = 'unknown';
            let userName = 'Unknown';
            const isStudent = await dbPool.query("SELECT name, class_name FROM hikvision_students WHERE nis = $1", [employeeNo]);
            if (isStudent.rowCount > 0 && isStudent.rows[0].class_name !== 'guru' && isStudent.rows[0].class_name !== 'karyawan') {
              personType = 'siswa';
              userName = isStudent.rows[0].name;
            } else {
              const isTeacher = await dbPool.query("SELECT id, payload FROM mst_teachers WHERE id = $1 OR payload->>'code' = $1 OR payload->>'nip' = $1", [employeeNo]);
              if (isTeacher.rowCount > 0) {
                personType = 'guru';
                const p = typeof isTeacher.rows[0].payload === 'string' ? JSON.parse(isTeacher.rows[0].payload) : isTeacher.rows[0].payload;
                userName = p.name || p.nama || isTeacher.rows[0].id;
              } else {
                const isStaff = await dbPool.query("SELECT id, payload FROM mst_staffs WHERE id = $1 OR payload->>'staff_code' = $1", [employeeNo]);
                if (isStaff.rowCount > 0) {
                  personType = 'karyawan';
                  const p = typeof isStaff.rows[0].payload === 'string' ? JSON.parse(isStaff.rows[0].payload) : isStaff.rows[0].payload;
                  userName = p.name || p.nama || isStaff.rows[0].id;
                } else {
                  if (isStudent.rowCount > 0) {
                    personType = isStudent.rows[0].class_name === 'karyawan' ? 'karyawan' : (isStudent.rows[0].class_name === 'guru' ? 'guru' : 'siswa');
                    userName = isStudent.rows[0].name;
                  }
                }
              }
            }

            await dbPool.query(
              "INSERT INTO hikvision_logs (device_id, employee_id, timestamp, event_type, person_type, created_at) VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)",
              [device.id, employeeNo, logTime, eventType, personType]
            );
            totalSaved++;

            const logDate = new Date(log.time);
            const hhmm = logDate.toTimeString().substring(0,5);
            
            let lateLimit = null;
            let roleTarget = null;
            if (personType === 'siswa') { lateLimit = config.siswa?.masuk_late; roleTarget = 'parent'; }
            else if (personType === 'guru') { lateLimit = config.guru?.masuk_late; roleTarget = 'kurikulum'; }
            else if (personType === 'karyawan') { lateLimit = config.karyawan?.masuk_late; roleTarget = 'tu'; }

            if (lateLimit && hhmm > lateLimit && eventType === '5-75') { 
               const message = `Pemberitahuan: ${personType.toUpperCase()} ${userName} (ID ${employeeNo}) absen masuk pada ${hhmm} (terlambat, batas: ${lateLimit}).`;
               await dbPool.query(
                 "INSERT INTO whatsapp_logs (phone, message, trigger_type, status) VALUES ($1, $2, $3, 'pending')",
                 [roleTarget, message, `late_${personType}`]
               );
            }
          }
        }
      } catch (e) {
        console.error(`Gagal pull log device ${device.ip_address}:`, e.message);
      }
    }
  } catch (err) {
    console.error("Error in pullHikvisionLogs:", err);
  }
  return { logs_found: totalFound, logs_saved: totalSaved };
}

async function sendDailyClassSummary() {
  if (!dbPool) return;
  try {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    
    // 1. Get classes and their homeroom teacher phones
    const { rows: mstRows } = await dbPool.query("SELECT payload FROM mst_classes");
    const classes = mstRows.map(r => r.payload);
    
    // We assume class payload has homeroom teacher info, or we look it up.
    // For this demonstration, we'll queue it if we know the phone.
    // In Kurmon, phone might be in `walas_phone` or we can find it in mst_teachers
    
    // Let's get all students' attendance for today
    // To do this properly, we iterate over classes
    for (const cls of classes) {
      if (!cls.id || !cls.walas_id) continue;
      
      const { rows: tRows } = await dbPool.query("SELECT payload FROM mst_teachers");
      const teachers = tRows.map(r => r.payload);
      const walas = teachers.find(t => t.id === cls.walas_id || t.code === cls.walas_id);
      
      if (!walas || !walas.phone) continue;
      
      // Get all students in this class
      const { rows: sRows } = await dbPool.query("SELECT nis, name FROM hikvision_students WHERE class_name = $1", [cls.id]);
      if (sRows.length === 0) continue;
      
      let hadir = 0;
      let tidakHadirNames = [];
      
      for (const s of sRows) {
        // Check if there's an attendance log for today
        const existing = await dbPool.query(
          "SELECT 1 FROM hikvision_logs WHERE employee_id = $1 AND timestamp::date = $2::date",
          [s.nis, today]
        );
        if (existing.rowCount > 0) {
          hadir++;
        } else {
          // Check manual attendance (izin/sakit)
          const manual = await dbPool.query(
            "SELECT status FROM attendance_manual WHERE user_id = $1 AND date = $2",
            [s.nis, today]
          );
          if (manual.rowCount > 0) {
             tidakHadirNames.push(`${s.name} (${manual.rows[0].status})`);
          } else {
             tidakHadirNames.push(`${s.name} (Alpa)`);
          }
        }
      }
      
      let tidakHadirCount = sRows.length - hadir;
      
      const message = `Halo Bapak/Ibu Wali Kelas ${cls.id},\nBerikut rekap absensi kelas hari ini (${today}):\n- Total Siswa: ${sRows.length}\n- Hadir: ${hadir}\n- Tidak Hadir: ${tidakHadirCount}\n\nDaftar Tidak Hadir:\n${tidakHadirNames.join('\\n')}`;
      
      await dbPool.query(
         "INSERT INTO whatsapp_logs (phone, message, trigger_type, status) VALUES ($1, $2, $3, 'pending')",
         [walas.phone, message, 'daily_recap_walas']
      );
    }
  } catch(e) {
    console.error("Error in sendDailyClassSummary:", e);
  }
}

const DEFAULT_ADMIN_PASSWORD = process.env.DEFAULT_ADMIN_PASSWORD || null;
const MAX_JSON_BODY_BYTES = 8_000_000;
const getDatabaseErrorMessage = (err) => {
  if (err?.code === "28P01") {
    return "Akses PostgreSQL ditolak. Periksa PG_USER dan PG_PASSWORD di file .env.";
  }
  if (err?.code === "ECONNREFUSED") {
    return "PostgreSQL belum aktif. Jalankan PostgreSQL, lalu restart auth server.";
  }
  if (err?.code === "3D000") {
    return "Database PostgreSQL tidak ditemukan dan gagal dibuat. Periksa izin user PostgreSQL di file .env.";
  }
  if (err?.code === "DB_PAYLOAD_INVALID") {
    return "Data utama di PostgreSQL rusak atau bukan JSON valid.";
  }
  return err?.message || "Database PostgreSQL gagal tersambung.";
};
const createDatabaseUnavailableError = () => {
  const error = new Error(dbStatus.message);
  error.code = dbStatus.code;
  error.statusCode = 503;
  return error;
};
const initDb = async () => {
  try {
    const adminPool = new pg.Pool({
      host: DB_CONFIG.host,
      port: DB_CONFIG.port,
      user: DB_CONFIG.user,
      password: DB_CONFIG.password,
      database: "postgres",
    });
    
    const dbCheck = await adminPool.query("SELECT 1 FROM pg_database WHERE datname = $1", [DB_CONFIG.database]);
    if (dbCheck.rowCount === 0) {
      await adminPool.query(`CREATE DATABASE "${DB_CONFIG.database}"`);
    }
    await adminPool.end();
    
    dbPool = new pg.Pool(DB_CONFIG);
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS app_data (
        id SERIAL PRIMARY KEY,
        store_key VARCHAR(50) UNIQUE,
        data TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS mst_majors (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
      CREATE TABLE IF NOT EXISTS mst_classes (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
      CREATE TABLE IF NOT EXISTS mst_rooms (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
      CREATE TABLE IF NOT EXISTS mst_teachers (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
      CREATE TABLE IF NOT EXISTS mst_subjects (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
      CREATE TABLE IF NOT EXISTS mst_students (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
      CREATE TABLE IF NOT EXISTS mst_staffs (
        id VARCHAR(255) PRIMARY KEY,
        payload JSONB NOT NULL
      );
    `);
    
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(255),
        role VARCHAR(50) NOT NULL DEFAULT 'siswa',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS attendances (
        id SERIAL PRIMARY KEY,
        user_id INT REFERENCES users(id) ON DELETE CASCADE,
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        status VARCHAR(50), student_nis VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS hikvision_devices (
        id SERIAL PRIMARY KEY,
        ip_address VARCHAR(100) NOT NULL,
        location VARCHAR(255),
        username VARCHAR(100) NOT NULL,
        encrypted_password TEXT NOT NULL,
        iv_vector VARCHAR(50) NOT NULL,
        class_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS hikvision_groups (
        id SERIAL PRIMARY KEY,
        device_id INT NOT NULL REFERENCES hikvision_devices(id) ON DELETE CASCADE,
        group_id VARCHAR(50) NOT NULL,
        group_name VARCHAR(100) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(device_id, group_id)
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS hikvision_students (
        id SERIAL PRIMARY KEY,
        nis VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        device_group_id INT REFERENCES hikvision_groups(id) ON DELETE SET NULL,
        class_name VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Ensure class_name exists in devices as well if we want to map whole device to class
    await dbPool.query(`ALTER TABLE hikvision_devices ADD COLUMN IF NOT EXISTS class_name VARCHAR(100)`);
    await dbPool.query(`ALTER TABLE hikvision_students ADD COLUMN IF NOT EXISTS class_name VARCHAR(100)`);
    await dbPool.query(`ALTER TABLE hikvision_students ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
    
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS hikvision_teachers (
        id SERIAL PRIMARY KEY,
        teacher_code VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        device_group_id INT REFERENCES hikvision_groups(id) ON DELETE SET NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS hikvision_staffs (
        id SERIAL PRIMARY KEY,
        staff_code VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        device_group_id INT REFERENCES hikvision_groups(id) ON DELETE SET NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS attendance_manual (
        id SERIAL PRIMARY KEY,
        user_type VARCHAR(50) NOT NULL,
        user_id VARCHAR(50) NOT NULL,
        date DATE NOT NULL,
        status VARCHAR(50) NOT NULL,
        reason TEXT,
        created_by VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    // Tipe mesin: siswa, guru, karyawan
    await dbPool.query(`ALTER TABLE hikvision_devices ADD COLUMN IF NOT EXISTS device_type VARCHAR(50) DEFAULT 'siswa'`);
    // Kolom person_type di log untuk membedakan siswa/guru/karyawan
    await dbPool.query(`ALTER TABLE hikvision_logs ADD COLUMN IF NOT EXISTS person_type VARCHAR(50) DEFAULT 'siswa'`);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS hikvision_logs (
        id SERIAL PRIMARY KEY,
        device_id INT NOT NULL REFERENCES hikvision_devices(id) ON DELETE CASCADE,
        employee_id VARCHAR(50) NOT NULL,
        timestamp TIMESTAMP NOT NULL,
        event_type VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_locations (
        id SERIAL PRIMARY KEY,
        nama_perusahaan VARCHAR(255) NOT NULL,
        bidang VARCHAR(100),
        alamat TEXT,
        kota VARCHAR(100),
        telepon VARCHAR(30),
        website VARCHAR(255),
        kuota INT DEFAULT 0,
        status VARCHAR(20) DEFAULT 'pending', student_nis VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Add extra columns if they don't exist (untuk koordinat, jurusan, kompetensi, dan verified)
    await dbPool.query(`
      ALTER TABLE pkl_locations 
      ADD COLUMN IF NOT EXISTS lat NUMERIC(10, 8),
      ADD COLUMN IF NOT EXISTS lng NUMERIC(11, 8),
      ADD COLUMN IF NOT EXISTS jurusan VARCHAR(100),
      ADD COLUMN IF NOT EXISTS kompetensi JSONB DEFAULT '[]'::jsonb,
      ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT false,
      ADD COLUMN IF NOT EXISTS submitted_by VARCHAR(20) DEFAULT 'admin';
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_logbooks (
        id SERIAL PRIMARY KEY,
        user_id INT REFERENCES users(id) ON DELETE CASCADE,
        tanggal DATE,
        kegiatan TEXT,
        catatan TEXT,
        status VARCHAR(20) DEFAULT 'pending', student_nis VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      ALTER TABLE pkl_logbooks 
      ADD COLUMN IF NOT EXISTS solusi TEXT,
      ADD COLUMN IF NOT EXISTS jam_masuk VARCHAR(10) DEFAULT '08:00',
      ADD COLUMN IF NOT EXISTS jam_keluar VARCHAR(10) DEFAULT '17:00',
      ADD COLUMN IF NOT EXISTS catatan_guru TEXT
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_submissions (
        id SERIAL PRIMARY KEY,
        user_id INT REFERENCES users(id) ON DELETE CASCADE,
        location_id INT REFERENCES pkl_locations(id) ON DELETE SET NULL,
        status VARCHAR(20) DEFAULT 'pending',
        catatan TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_students (
        nis VARCHAR(50) PRIMARY KEY,
        location_id INT REFERENCES pkl_locations(id) ON DELETE SET NULL,
        teacher_code VARCHAR(100),
        status VARCHAR(50) DEFAULT 'aktif',
        start_date DATE,
        end_date DATE,
        location_update_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`ALTER TABLE pkl_students ADD COLUMN IF NOT EXISTS location_update_count INT DEFAULT 0`);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_surat_pengantar (
        id SERIAL PRIMARY KEY,
        location_id INT REFERENCES pkl_locations(id) ON DELETE SET NULL,
        pt_name_temp VARCHAR(255),
        nomor_surat VARCHAR(100),
        status VARCHAR(20) DEFAULT 'pending',
        created_by_nis VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_surat_pengantar_students (
        id SERIAL PRIMARY KEY,
        surat_id INT NOT NULL REFERENCES pkl_surat_pengantar(id) ON DELETE CASCADE,
        nis VARCHAR(50) NOT NULL,
        nama VARCHAR(255) NOT NULL,
        kelas VARCHAR(50),
        nisn VARCHAR(50)
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS pkl_mutasi (
        id SERIAL PRIMARY KEY,
        nis VARCHAR(50) NOT NULL,
        old_location_id INT REFERENCES pkl_locations(id) ON DELETE SET NULL,
        new_location_id INT REFERENCES pkl_locations(id) ON DELETE SET NULL,
        new_pt_name_temp VARCHAR(255),
        alasan TEXT,
        acc_walas VARCHAR(20) DEFAULT 'pending',
        acc_pembimbing VARCHAR(20) DEFAULT 'pending',
        acc_kaprog VARCHAR(20) DEFAULT 'pending',
        acc_hubin VARCHAR(20) DEFAULT 'pending',
        final_status VARCHAR(20) DEFAULT 'pending', student_nis VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS kedisiplinan_master_poin (
        id SERIAL PRIMARY KEY,
        nama_tindakan VARCHAR(255) NOT NULL,
        jenis VARCHAR(50) NOT NULL,
        nilai_poin INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS kedisiplinan_jadwal_mingguan (
        id SERIAL PRIMARY KEY,
        hari VARCHAR(20) NOT NULL,
        kampus VARCHAR(50) NOT NULL,
        guru_ids JSONB DEFAULT '[]'::jsonb,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(hari, kampus)
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS kedisiplinan_riwayat_poin (
        id SERIAL PRIMARY KEY,
        siswa_nis VARCHAR(50) NOT NULL,
        tindakan_id INT REFERENCES kedisiplinan_master_poin(id) ON DELETE SET NULL,
        tindakan_nama VARCHAR(255),
        poin INT,
        jenis VARCHAR(50),
        pelapor_id VARCHAR(50),
        pelapor_nama VARCHAR(100),
        catatan TEXT,
        tanggal_kejadian TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS kedisiplinan_buku_konseling (
        id SERIAL PRIMARY KEY,
        siswa_nis VARCHAR(50) NOT NULL,
        guru_bk_id VARCHAR(50),
        guru_bk_nama VARCHAR(100),
        jenis_kasus VARCHAR(50),
        tindak_lanjut TEXT,
        catatan_konseling TEXT,
        status VARCHAR(50) DEFAULT 'Selesai',
        tanggal_konseling TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS kedisiplinan_absensi (
        id SERIAL PRIMARY KEY,
        siswa_nis VARCHAR(50) NOT NULL,
        tanggal DATE NOT NULL,
        status VARCHAR(50) NOT NULL,
        keterangan TEXT,
        pelapor_id VARCHAR(50),
        pelapor_nama VARCHAR(100),
        gdrive_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // === TABEL BARU: FITUR TAMBAHAN ===

    // Profil Sekolah
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS school_profile (
        id SERIAL PRIMARY KEY,
        key VARCHAR(100) UNIQUE NOT NULL,
        value TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Tahun Ajaran
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS academic_years (
        id SERIAL PRIMARY KEY,
        nama VARCHAR(100) NOT NULL,
        semester VARCHAR(20) NOT NULL DEFAULT 'Ganjil',
        tanggal_mulai DATE,
        tanggal_selesai DATE,
        is_active BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // API Keys / Integrasi
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS api_keys (
        id SERIAL PRIMARY KEY,
        service_name VARCHAR(100) UNIQUE NOT NULL,
        service_label VARCHAR(100),
        api_key TEXT,
        extra_config JSONB DEFAULT '{}'::jsonb,
        is_active BOOLEAN DEFAULT false,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Audit Log (Activity Trail)
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(100),
        user_name VARCHAR(255),
        user_role VARCHAR(50),
        action VARCHAR(100) NOT NULL,
        target_type VARCHAR(100),
        target_id VARCHAR(100),
        detail TEXT,
        ip_address VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Kartu Pelajar (Student ID Card Templates)
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS student_card_templates (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        config JSONB DEFAULT '{}'::jsonb,
        is_default BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // WhatsApp Log
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS whatsapp_logs (
        id SERIAL PRIMARY KEY,
        phone VARCHAR(30) NOT NULL,
        recipient_name VARCHAR(255),
        message TEXT NOT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        trigger_type VARCHAR(50),
        response_data JSONB,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // E-Surat Templates
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS esurat_templates (
        id SERIAL PRIMARY KEY,
        jenis VARCHAR(50) NOT NULL,
        nama VARCHAR(100) NOT NULL,
        isi_template TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Kenaikan Kelas Arsip
    await dbPool.query(`
      CREATE TABLE IF NOT EXISTS kenaikan_kelas_log (
        id SERIAL PRIMARY KEY,
        tahun_ajaran VARCHAR(50) NOT NULL,
        tanggal_proses TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        jumlah_naik INT DEFAULT 0,
        jumlah_lulus INT DEFAULT 0,
        detail JSONB DEFAULT '[]'::jsonb,
        processed_by VARCHAR(100)
      )
    `);

    // Auto-align sequences to prevent duplicate key violations (hikvision_logs_pkey, etc.)
    try {
      const seqRows = await dbPool.query(`
        SELECT t.table_name, c.column_name
        FROM information_schema.tables t
        JOIN information_schema.columns c ON t.table_name = c.table_name
        WHERE t.table_schema = 'public' 
          AND c.column_default LIKE 'nextval%'
      `);
      for (const row of seqRows.rows) {
        const tableName = row.table_name;
        const columnName = row.column_name;
        const seqRes = await dbPool.query(
          "SELECT pg_get_serial_sequence('" + tableName + "', '" + columnName + "') AS seq"
        );
        const seqName = seqRes.rows[0]?.seq;
        if (seqName) {
          await dbPool.query(
            "SELECT setval('" + seqName + "', COALESCE((SELECT MAX(" + columnName + ") FROM " + tableName + "), 1), true)"
          );
        }
      }
      console.log("PostgreSQL Database sequences aligned successfully.");
    } catch (seqErr) {
      console.warn("Gagal menyelaraskan sequences:", seqErr.message);
    }

    dbStatus = { ok: true, code: "DB_CONNECTED", message: "Database PostgreSQL tersambung." };
    console.log("PostgreSQL Database Initialized & Connected");
  } catch (err) {
    dbStatus = {
      ok: false,
      code: err?.code || "DB_CONNECT_ERROR",
      message: getDatabaseErrorMessage(err),
    };
    console.error(dbStatus.message, err);
  }
};
await initDb();

const FRONTEND_PORT = Number.parseInt(process.env.VITE_PORT || "6677", 10);
const AUTH_BIND_HOST = process.env.AUTH_BIND_HOST || "0.0.0.0";
const ALLOWED_ORIGINS = buildAllowedOrigins({ env: process.env, frontendPort: FRONTEND_PORT });
import { existsSync, writeFileSync } from "node:fs";

const sessionsFile = resolve(storeDir, "sessions.json");
let sessions = new Map();
try {
  if (existsSync(sessionsFile)) {
    const data = readFileSync(sessionsFile, "utf8");
    sessions = new Map(Object.entries(JSON.parse(data)));
  }
} catch (e) {
  sessions = new Map();
}

const saveSessions = () => {
  try {
    writeFileSync(sessionsFile, JSON.stringify(Object.fromEntries(sessions)));
  } catch (e) {}
};

const getHeaders = (req) => {
  const origin = req.__corsOrigin || resolveCorsOrigin(req.headers.origin, ALLOWED_ORIGINS);
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Credentials": "true",
    "Vary": "Origin",
  };
  if (origin) {
    headers["Access-Control-Allow-Origin"] = origin;
  }
  return headers;
};

const publicAdminUser = (adminUser) => ({
  username: adminUser?.username || "",
  name: adminUser?.name || "Administrator",
});

const getBearerToken = (req) => {
  const auth = String(req.headers.authorization || "");
  return auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
};

const getSession = (req) => sessions.get(getBearerToken(req));
const normalizeServerRole = (role) => {
  if (role === "superadmin" || role === "admin") return "admin";
  if (role === "kepsek" || role === "waka" || role === "kaprog" || role === "guru" || role === "tu" || role === "tata_usaha") return role === "tata_usaha" ? "tu" : role;
  if (role === "hubin" || role === "sarpras" || role === "kurikulum") return role;
  if (role === "siswa") return "siswa";
  if (role === "walas") return "walas";
  return "guru";
};
const isAdminRole = (role) => normalizeServerRole(role) === "admin";
const isMonitoringAdmin = (role) => ["admin", "hubin", "waka", "kaprog"].includes(normalizeServerRole(role));

const requireAdmin = (req, res) => {
  const session = getSession(req);
  if (isAdminRole(session?.role)) return session;
  send(req, res, 403, { ok: false, error: "Sesi admin diperlukan." });
  return null;
};

const requireAdminOrTu = (req, res) => {
  const session = getSession(req);
  const role = normalizeServerRole(session?.role);
  if (role === "admin" || role === "tu") return session;
  send(req, res, 403, { ok: false, error: "Sesi admin atau tata usaha diperlukan." });
  return null;
};

const requireAuthenticated = (req, res) => {
  const session = getSession(req);
  const allowed = ["admin", "guru", "kepsek", "waka", "kaprog", "hubin", "sarpras", "kurikulum", "siswa", "walas", "tu", "bk"];
  if (session && allowed.includes(normalizeServerRole(session.role))) return session;
  send(req, res, 403, { ok: false, error: "Sesi login diperlukan." });
  return null;
};

const createSession = (role, extra = {}) => {
  const token = randomUUID();
  sessions.set(token, { role: normalizeServerRole(role), createdAt: Date.now(), ...extra });
  saveSessions();
  return token;
};



const readJsonBody = (req) => new Promise((resolveBody, rejectBody) => {
  let raw = "";
  req.on("data", (chunk) => {
    raw += chunk;
    if (raw.length > MAX_JSON_BODY_BYTES) {
      rejectBody(new Error("Payload terlalu besar."));
      req.destroy();
    }
  });
  req.on("end", () => {
    if (!raw) return resolveBody({});
    try {
      resolveBody(JSON.parse(raw));
    } catch (error) {
      rejectBody(error);
    }
  });
  req.on("error", rejectBody);
});

const send = (req, res, statusCode, payload) => {
  res.writeHead(statusCode, getHeaders(req));
  res.end(JSON.stringify(payload));
};

const sanitizePayload = (payload = {}) => {
  const safeTeachers = Array.isArray(payload.teachers)
    ? payload.teachers.map(({ password, ...teacher }) => teacher)
    : [];
  const safeAdminUser = payload.adminUser
    ? (({ password, ...admin }) => admin)(payload.adminUser)
    : null;
  const { currentUser, ...rest } = payload;
  return { ...rest, adminUser: safeAdminUser, teachers: safeTeachers, currentUser: null };
};

const toPublicPayload = (payload = {}) => {
  const safe = sanitizePayload(payload);
  return {
    advancedRules: safe.advancedRules,
    appSettings: safe.appSettings,
    classes: safe.classes,
    days: safe.days,
    isGenerated: safe.isGenerated,
    layoutBlockLabels: safe.layoutBlockLabels,
    layoutByDay: safe.layoutByDay,
    layoutPreset: safe.layoutPreset,
    majors: safe.majors,
    roomLayout: safe.roomLayout,
    rooms: safe.rooms,
    schedule: safe.schedule,
    subjects: safe.subjects,
    academicCalendar: safe.academicCalendar,
    calendarCategories: safe.calendarCategories,
    featureSettings: safe.featureSettings,
    rolePermissions: safe.rolePermissions,
    syllabuses: safe.syllabuses,
    teacherAvailability: safe.teacherAvailability,
    teachers: safe.teachers,
    adminUser: safe.adminUser,
    teachingLoads: safe.teachingLoads,
    timeSlots: safe.timeSlots,
    strukturOrganisasi: safe.strukturOrganisasi,
    mitraKerjasama: safe.mitraKerjasama,
  };
};

const readMainPayload = async () => {
  if (!dbPool) throw createDatabaseUnavailableError();
  const { rows } = await dbPool.query(`SELECT data FROM app_data WHERE store_key = 'main_store'`);
  if (rows.length === 0 || !rows[0].data) return null;
  try {
    return JSON.parse(rows[0].data);
  } catch (error) {
    const invalidPayloadError = new Error(getDatabaseErrorMessage({ code: "DB_PAYLOAD_INVALID" }));
    invalidPayloadError.code = "DB_PAYLOAD_INVALID";
    invalidPayloadError.statusCode = 500;
    throw invalidPayloadError;
  }
};

const getHikvisionConfig = async () => {
  const defaultConf = {
    masuk_open: "05:00",
    masuk_late: "07:15",
    masuk_close: "11:00",
    pulang_open: "14:00",
    pulang_close: "18:00",
    siswa: { masuk_open: "05:00", masuk_late: "07:15", masuk_close: "11:00", pulang_open: "14:00", pulang_close: "18:00" },
    guru: { masuk_open: "05:00", masuk_late: "07:00", masuk_close: "11:00", siang_open: "11:00", siang_close: "14:00", pulang_open: "14:00", pulang_close: "18:00" },
    karyawan: { masuk_open: "05:00", masuk_late: "07:00", masuk_close: "11:00", pulang_open: "15:00", pulang_close: "18:00" },
    notify_role: "none",
    notify_custom_phone: ""
  };
  try {
    if (!dbPool) return defaultConf;
    const res = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'hikvision_attendance_config'");
    if (res.rowCount > 0 && res.rows[0].data) {
      return { ...defaultConf, ...JSON.parse(res.rows[0].data) };
    }
  } catch (e) {
    console.error("Failed to load hikvision config:", e);
  }
  return defaultConf;
};

const sendDatabaseError = (req, res, err) => {
  const statusCode = err?.statusCode || (!dbPool ? 503 : 500);
  send(req, res, statusCode, {
    ok: false,
    error: getDatabaseErrorMessage(err),
    code: err?.code || dbStatus.code || "DATABASE_ERROR",
  });
};

const ensureDatabaseReadable = async (req, res) => {
  try {
    await readMainPayload();
    return true;
  } catch (err) {
    console.error("Database Readiness Error:", err);
    sendDatabaseError(req, res, err);
    return false;
  }
};





const server = createServer(async (req, res) => {
  console.log("Req:", req.url);
  const corsOrigin = resolveCorsOrigin(req.headers.origin, ALLOWED_ORIGINS);
  req.__corsOrigin = corsOrigin;

  if (req.headers.origin && !corsOrigin) {
    res.writeHead(403, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify({ ok: false, error: "Origin tidak diizinkan." }));
    return;
  }

  if (req.method === "OPTIONS") {
    res.writeHead(204, getHeaders(req));
    res.end();
    return;
  }

  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);

  try {
      if (req.method === "GET" && url.pathname === "/api/student/verify") {
        try {
          const nis = url.searchParams.get("nis");
          const payload = await readMainPayload();
    let students = payload?.students || [];
    try {
      const dbStudents = await dbPool.query('SELECT payload FROM mst_students');
      if (dbStudents.rows.length > 0) students = dbStudents.rows.map(r => r.payload);
    } catch(e) {}
    if (!students || students.length === 0) return send(req, res, 404, { ok: false, message: "No data" });
    const student = students.find(s => String(s.nis) === String(nis));
    if (student) {
            send(req, res, 200, { ok: true, student, school: payload?.school || {} });
          } else {
            send(req, res, 404, { ok: false, message: "Student not found" });
          }
        } catch (err) {
          console.error("Verify Error:", err);
          sendDatabaseError(req, res, err);
        }
        return;
      }

    /* /api/data routes removed */

    /* /api/auth routes removed */

    
    /* /api/settings routes removed */

    if (req.method === "GET" && url.pathname === "/api/monitoring/pkl-students") {
      if (!requireAuthenticated(req, res)) return;
      if (!dbPool) { send(req, res, 503, { ok: false, error: dbStatus.message }); return; }
      try {
        const payload = await readMainPayload();
        let studentsArray = payload?.students || [];
        try {
          const dbStudents = await dbPool.query('SELECT payload FROM mst_students');
          if (dbStudents.rows.length > 0) studentsArray = dbStudents.rows.map(r => r.payload);
        } catch(e) {}
        const activeNisList = Array.isArray(studentsArray) ? studentsArray.map(s => String(s.nis)) : [];

        const { rows } = await dbPool.query(`
          SELECT 
            p.nis, p.location_id, p.teacher_code, p.status, p.location_update_count,
            COUNT(l.id) FILTER (WHERE l.status = 'approved') as total_hadir,
            0 as total_izin,
            0 as total_absen
          FROM pkl_students p
          LEFT JOIN pkl_logbooks l ON p.nis = l.student_nis
          GROUP BY p.nis
        `);
        
        const filteredRows = rows.filter(r => activeNisList.includes(String(r.nis)));
        send(req, res, 200, { ok: true, data: filteredRows });
      } catch (err) {
        if (err.code === "42P01") send(req, res, 200, { ok: true, data: [] });
        else sendDatabaseError(req, res, err);
      }
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/monitoring/pkl-students/bulk") {
      const session = getSession(req);
      if (!isAdminRole(session?.role)) return send(req, res, 403, { ok: false, error: "Hanya admin" });
      if (!dbPool) { send(req, res, 503, { ok: false, error: dbStatus.message }); return; }
      const body = await readJsonBody(req);
      const updates = Array.isArray(body.updates) ? body.updates : [];
      try {
        for (const u of updates) {
           await dbPool.query(`
             INSERT INTO pkl_students (nis, location_id, teacher_code, status)
             VALUES ($1, $2, $3, $4)
             ON CONFLICT (nis) DO UPDATE SET
               location_id = EXCLUDED.location_id,
               teacher_code = EXCLUDED.teacher_code,
               status = EXCLUDED.status,
               created_at = CURRENT_TIMESTAMP
           `, [u.nis, u.location_id || null, u.teacher_code || null, u.status || 'aktif']);
        }
        send(req, res, 200, { ok: true });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    // ── PKL Dashboard Stats ─────────────────────────────────────────

    // ── Dashboard Logs (Login, Absen Guru, Siswa Terlambat, Siswa Bermasalah) ───
    if (req.method === "GET" && url.pathname === "/api/dashboard/logs") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      try {
        let loginLogs = [];
        let teacherAbsenceLogs = [];
        let latestStudentLogs = [];
        let problematicStudentLogs = [];

        // Fetch main store payload for student & teacher names
        let students = [];
        let teachers = [];
        let rawTeacherAbsenceLogs = [];
        try {
          const storeRes = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'main_store'");
          const mainData = storeRes.rows[0]?.data ? (typeof storeRes.rows[0].data === 'string' ? JSON.parse(storeRes.rows[0].data) : storeRes.rows[0].data) : {};
          students = mainData.students || [];
          try {
             const dbS = await dbPool.query('SELECT payload FROM mst_students');
             if (dbS.rows.length > 0) students = dbS.rows.map(r => r.payload);
          } catch(e) {}
          teachers = mainData.teachers || [];
          try {
             const dbT = await dbPool.query('SELECT payload FROM mst_teachers');
             if (dbT.rows.length > 0) teachers = dbT.rows.map(r => r.payload);
          } catch(e) {}
          rawTeacherAbsenceLogs = mainData.attendanceRecords || [];
        } catch (e) {
          console.error("Failed to read main store for dashboard logs:", e);
        }

        const getStudentName = (nis) => {
          const s = students.find(x => String(x.nis).trim() === String(nis).trim());
          return s ? s.name : nis;
        };

        const getTeacherName = (code) => {
          const t = teachers.find(x => String(x.code).trim() === String(code).trim());
          return t ? t.name : code;
        };

        // 1. Try login logs (only for admins)
        if (session.role === "admin" || session.role === "superadmin") {
          try {
            const loginRes = await dbPool.query(`
              SELECT username, role, created_at as time, 'success' as status
              FROM login_logs
              ORDER BY created_at DESC LIMIT 20
            `);
            loginLogs = loginRes.rows;
          } catch {
            await dbPool.query(`
              CREATE TABLE IF NOT EXISTS login_logs (
                id SERIAL PRIMARY KEY,
                username TEXT,
                role TEXT,
                ip TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW()
              )
            `);
            loginLogs = [];
          }
        } else {
          loginLogs = [];
        }

        // 2. Teacher absence (absences where guru status is not 'Hadir' or 'Masuk')
        try {
          teacherAbsenceLogs = rawTeacherAbsenceLogs
            .filter(r => r.status && r.status.toLowerCase() !== 'hadir' && r.status.toLowerCase() !== 'masuk')
            .map(r => ({
              nis: r.teacherCode || r.username,
              name: getTeacherName(r.teacherCode || r.username),
              username: r.teacherCode || r.username,
              status: r.status,
              date: r.date,
              created_at: r.created_at || r.date
            }))
            .slice(0, 20);
        } catch (e) {
          teacherAbsenceLogs = [];
        }

        // 2.2 Calculate teacher attendance rankings
        let teacherAttendanceRankings = [];
        try {
          const teacherMap = new Map();
          teachers.forEach(t => {
            teacherMap.set(String(t.code).trim(), {
              code: t.code,
              name: t.name || t.code,
              type: t.type || 'Umum',
              hadir: 0,
              sakit: 0,
              izin: 0,
              alpa: 0,
              total_absen: 0
            });
          });

          rawTeacherAbsenceLogs.forEach(r => {
            const key = String(r.teacherCode || r.username).trim();
            if (teacherMap.has(key)) {
              const val = teacherMap.get(key);
              const status = String(r.status || '').toLowerCase();
              if (status === 'hadir' || status === 'masuk') {
                val.hadir += 1;
              } else if (status === 'sakit') {
                val.sakit += 1;
                val.total_absen += 1;
              } else if (status === 'izin') {
                val.izin += 1;
                val.total_absen += 1;
              } else if (status === 'alpa' || status === 'alpha') {
                val.alpa += 1;
                val.total_absen += 1;
              } else if (status !== '') {
                val.total_absen += 1;
              }
            }
          });

          teacherAttendanceRankings = Array.from(teacherMap.values())
            .sort((a, b) => {
              if (b.total_absen !== a.total_absen) {
                return b.total_absen - a.total_absen;
              }
              return b.hadir - a.hadir;
            })
            .slice(0, 10);
        } catch (e) {
          console.error("Failed to calculate teacher attendance rankings:", e);
        }

        // 3. Late students (terlambat)
        try {
          const lateRes = await dbPool.query(`
            SELECT student_nis as nis, status, created_at
            FROM attendances
            WHERE status = 'terlambat'
            ORDER BY created_at DESC LIMIT 20
          `);
          latestStudentLogs = lateRes.rows.map(r => ({
            nis: r.nis,
            name: getStudentName(r.nis),
            username: r.nis,
            status: r.status,
            created_at: r.created_at
          }));
        } catch {
          latestStudentLogs = [];
        }

        // 3.2 Student absence logs (Sakit, Izin, Alpa)
        let studentAbsenceLogs = [];
        try {
          const sAbsRes = await dbPool.query(`
            SELECT siswa_nis as nis, status, tanggal as date, created_at, keterangan, pelapor_nama
            FROM kedisiplinan_absensi
            ORDER BY tanggal DESC, id DESC LIMIT 20
          `);
          studentAbsenceLogs = sAbsRes.rows.map(r => ({
            nis: r.nis,
            name: getStudentName(r.nis),
            status: r.status,
            date: r.date,
            keterangan: r.keterangan,
            pelapor_nama: r.pelapor_nama,
            created_at: r.created_at || r.date
          }));
        } catch (e) {
          console.error("Failed to fetch studentAbsenceLogs:", e);
        }

        // 3.3 Calculate student attendance rankings
        let studentAttendanceRankings = [];
        try {
          // Get count of Sakit, Izin, Alpha for each student from kedisiplinan_absensi
          const absRes = await dbPool.query(`
            SELECT siswa_nis as nis, 
                   SUM(CASE WHEN status = 'Alpa' OR status = 'Alpha' THEN 1 ELSE 0 END) as alpha,
                   SUM(CASE WHEN status = 'Izin' THEN 1 ELSE 0 END) as izin,
                   SUM(CASE WHEN status = 'Sakit' THEN 1 ELSE 0 END) as sakit,
                   COUNT(*) as total_tidak_hadir
            FROM kedisiplinan_absensi
            GROUP BY siswa_nis
          `);

          // Get count of lates from attendances
          const lateRes = await dbPool.query(`
            SELECT student_nis as nis, COUNT(*) as late_count
            FROM attendances
            WHERE status = 'terlambat'
            GROUP BY student_nis
          `);

          const studentMap = new Map();
          students.forEach(s => {
            studentMap.set(String(s.nis).trim(), {
              nis: s.nis,
              name: s.namaSiswa || s.name || s.nis,
              class_name: s.class_name || '-',
              alpha: 0,
              izin: 0,
              sakit: 0,
              terlambat: 0,
              total_absen: 0
            });
          });

          absRes.rows.forEach(r => {
            const key = String(r.nis).trim();
            if (studentMap.has(key)) {
              const val = studentMap.get(key);
              val.alpha = parseInt(r.alpha) || 0;
              val.izin = parseInt(r.izin) || 0;
              val.sakit = parseInt(r.sakit) || 0;
              val.total_absen += (val.alpha + val.izin + val.sakit);
            } else {
              studentMap.set(key, {
                nis: r.nis,
                name: getStudentName(r.nis),
                class_name: '-',
                alpha: parseInt(r.alpha) || 0,
                izin: parseInt(r.izin) || 0,
                sakit: parseInt(r.sakit) || 0,
                terlambat: 0,
                total_absen: (parseInt(r.alpha) || 0) + (parseInt(r.izin) || 0) + (parseInt(r.sakit) || 0)
              });
            }
          });

          lateRes.rows.forEach(r => {
            const key = String(r.nis).trim();
            if (studentMap.has(key)) {
              const val = studentMap.get(key);
              val.terlambat = parseInt(r.late_count) || 0;
              val.total_absen += val.terlambat;
            } else {
              studentMap.set(key, {
                nis: r.nis,
                name: getStudentName(r.nis),
                class_name: '-',
                alpha: 0,
                izin: 0,
                sakit: 0,
                terlambat: parseInt(r.late_count) || 0,
                total_absen: parseInt(r.late_count) || 0
              });
            }
          });

          studentAttendanceRankings = Array.from(studentMap.values())
            .sort((a, b) => {
              if (b.total_absen !== a.total_absen) {
                return b.total_absen - a.total_absen;
              }
              return String(a.name).localeCompare(String(b.name));
            })
            .slice(0, 10);
        } catch (e) {
          console.error("Failed to calculate student attendance rankings:", e);
        }

        // 4. Problematic students (points violations + alpha)
        try {
          let pointsList = [];
          try {
            const pointsRes = await dbPool.query(`
              SELECT siswa_nis as nis, SUM(poin) as total_poin, MAX(created_at) as last_seen
              FROM kedisiplinan_riwayat_poin
              GROUP BY siswa_nis
              ORDER BY total_poin DESC LIMIT 20
            `);
            pointsList = pointsRes.rows;
          } catch (e) {
            console.error("pointsList query error:", e);
          }

          let alphaList = [];
          try {
            const alphaRes = await dbPool.query(`
              SELECT student_nis as nis, COUNT(*) as total_alpha, MAX(created_at) as last_seen
              FROM attendances
              WHERE status IN ('absen', 'alpha')
              GROUP BY student_nis
              HAVING COUNT(*) >= 2
              ORDER BY total_alpha DESC LIMIT 20
            `);
            alphaList = alphaRes.rows;
          } catch (e) {
            console.error("alphaList query error:", e);
          }

          const mergedProblems = new Map();
          pointsList.forEach(r => {
            mergedProblems.set(r.nis, {
              nis: r.nis,
              name: getStudentName(r.nis),
              total_alpha: `${r.total_poin} poin`,
              last_seen: r.last_seen
            });
          });

          alphaList.forEach(r => {
            const existing = mergedProblems.get(r.nis);
            if (existing) {
              existing.total_alpha = `${existing.total_alpha} / ${r.total_alpha}x alpha`;
              if (new Date(r.last_seen) > new Date(existing.last_seen)) {
                existing.last_seen = r.last_seen;
              }
            } else {
              mergedProblems.set(r.nis, {
                nis: r.nis,
                name: getStudentName(r.nis),
                total_alpha: `${r.total_alpha}x alpha`,
                last_seen: r.last_seen
              });
            }
          });

          problematicStudentLogs = Array.from(mergedProblems.values())
            .sort((a, b) => new Date(b.last_seen) - new Date(a.last_seen))
            .slice(0, 20);
        } catch (e) {
          console.error("Failed to construct problematicStudentLogs:", e);
          problematicStudentLogs = [];
        }

        return send(req, res, 200, {
          ok: true,
          data: { 
            loginLogs, 
            teacherAbsenceLogs, 
            latestStudentLogs, 
            studentAbsenceLogs, 
            problematicStudentLogs, 
            studentAttendanceRankings, 
            teacherAttendanceRankings 
          }
        });
      } catch (err) {
        return sendDatabaseError(req, res, err);
      }
    }


    

    // Admin: approve (verify) a student-submitted PKL location



    // 🧑‍🎓 PKL Student Self-Service Endpoints 🧑‍🎓


    if (req.method === "POST" && url.pathname === "/api/attendances/student") {
      const session = requireAuthenticated(req, res);
      if (!session || session.role !== "siswa") return send(req, res, 403, { ok: false, error: "Hanya siswa" });
      try {
        const body = await readJsonBody(req);
        const nis = session.id || session.username;
        await dbPool.query(`
          INSERT INTO attendances (student_nis, latitude, longitude, status)
          VALUES ($1, $2, $3, $4)
        `, [nis, body.lat, body.lng, body.status || 'hadir']);
        return send(req, res, 200, { ok: true });
      } catch (err) {
        return sendDatabaseError(req, res, err);
      }
    }

    if (req.method === "GET" && url.pathname === "/api/attendances/student") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      try {
        const nis = session.id || session.username;
        const result = await dbPool.query("SELECT * FROM attendances WHERE student_nis = $1 ORDER BY created_at DESC", [nis]);
        return send(req, res, 200, { ok: true, data: result.rows });
      } catch (err) {
        if (err.code === '42P01') return send(req, res, 200, { ok: true, data: [] });
        return sendDatabaseError(req, res, err);
      }
    }

    // GET /api/attendances — Admin: get all attendance records (with optional date/nis filters)
    if (req.method === "GET" && url.pathname === "/api/attendances") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const nisFilter = url.searchParams.get("nis");
        const dateFilter = url.searchParams.get("date");
        let q = "SELECT * FROM attendances";
        const params = [];
        const conds = [];
        if (nisFilter) { params.push(nisFilter); conds.push(`student_nis = $${params.length}`); }
        if (dateFilter) { params.push(dateFilter); conds.push(`DATE(created_at) = $${params.length}`); }
        if (conds.length) q += " WHERE " + conds.join(" AND ");
        q += " ORDER BY created_at DESC LIMIT 500";
        const result = await dbPool.query(q, params);
        return send(req, res, 200, { ok: true, data: result.rows });
      } catch (err) {
        if (err.code === "42P01") return send(req, res, 200, { ok: true, data: [] });
        return sendDatabaseError(req, res, err);
      }
    }

    // GET /api/pkl/students/:nis — Get single PKL student record by NIS



    // 📓 PKL Logbooks & Submissions 📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓📓─────────────────────────────────────────
    

    // ── Surat Pengantar PKL ─────────────────────────────────────────




    // ── Konfirmasi PKL (Lapor) ──────────────────────────────────────

    // ── Mutasi PKL (Pindah Tempat) ──────────────────────────────────



    // ── Monitoring public: Data Tempat PKL ──────────────────────────
    if (req.method === "GET" && url.pathname === "/api/monitoring/lokasi-pkl/public") {
      if (!dbPool) { send(req, res, 503, { ok: false, error: dbStatus.message }); return; }
      try {
        const { rows } = await dbPool.query(
          `SELECT id, nama_perusahaan, bidang, alamat, kota, telepon, website, kuota, lat, lng, jurusan, verified, status
           FROM pkl_locations WHERE status = 'aktif' OR status = 'approved' OR verified = true ORDER BY nama_perusahaan`
        );
        send(req, res, 200, { ok: true, data: rows });
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }

    // ── Monitoring siswa login via users table ───────────────────────
    if (req.method === "POST" && url.pathname === "/api/auth/login") {
      // Handled above
    }

        // ── HIKVISION ABSENSI API ───────────────────────────────────────










    // ── SYNC GURU/KARYAWAN dari mesin ───────────────────────────────────

    // ── SINKRONISASI LOG HIKVISION GURU → REKAP ABSENSI GURU ─────────────

    // ── HIKVISION CONFIG ──────────────────────────────────────────────


    // ── INPUT MANUAL ABSENSI GURU (IZIN/SAKIT) & NOTIFIKASI ─────────────

    // ── SINKRONISASI NAMA GURU DARI MESIN → mst_teachers ─────────────────


    // ── HIKVISION STUDENTS & MAPPING ──────────────────────────────────



    // ── HIKVISION MATRIX REPORT ───────────────────────────────────────
    // === API KEDISIPLINAN ===

    



    const ctx = { dbPool, send, sendDatabaseError, requireAuthenticated, getSession, readJsonBody, readMainPayload, isMonitoringAdmin, isAdminRole, createDatabaseUnavailableError, syncAllUsersToModules, toPublicPayload, sanitizePayload, verifyPassword, createSession, ensureDatabaseReadable, normalizeServerRole, dbStatus };
    
    if (url.pathname.startsWith("/api/data")) {
        const handled = await handleDataRoutes(req, res, url, ctx);
        if (handled !== false) return;
    }
    if (url.pathname.startsWith("/api/auth")) {
        const handled = await handleAuthRoutes(req, res, url, ctx);
        if (handled !== false) return;
    }
    if (url.pathname.startsWith("/api/settings")) {
        const handled = await handleSettingsRoutes(req, res, url, ctx);
        if (handled !== false) return;
    }
    if (url.pathname.startsWith("/api/pkl")) {
        const handled = await handlePklRoutes(req, res, url, ctx);
        if (handled !== false) return;
    }
    if (url.pathname.startsWith("/api/hikvision")) {
        const handled = await handleHikvisionRoutes(req, res, url, ctx);
        if (handled !== false) return;
    }
    if (url.pathname.startsWith("/api/kedisiplinan")) {
        const handled = await handleKedisiplinanRoutes(req, res, url, ctx);
        if (handled !== false) return;
    }

    // === API: PROFIL SEKOLAH ===
    if (url.pathname === "/api/school-profile") {
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT key, value FROM school_profile");
          const profile = {};
          rows.forEach(r => { profile[r.key] = r.value; });
          send(req, res, 200, { ok: true, data: profile });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        if (!requireAdmin(req, res)) return;
        try {
          const body = await readJsonBody(req);
          const session = getSession(req);
          for (const [key, value] of Object.entries(body)) {
            await dbPool.query(
              "INSERT INTO school_profile (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP",
              [key, String(value ?? "")]
            );
          }
          await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1, $2, $3, $4, $5, $6)",
            [session?.id || "system", session?.name || "Admin", session?.role || "admin", "UPDATE", "school_profile", "Update profil sekolah"]);
          send(req, res, 200, { ok: true });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // === API: TAHUN AJARAN ===
    if (url.pathname.startsWith("/api/academic-years")) {
      if (!requireAuthenticated(req, res)) return;
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT * FROM academic_years ORDER BY created_at DESC");
          send(req, res, 200, { ok: true, data: rows });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        if (!requireAdmin(req, res)) return;
        try {
          const body = await readJsonBody(req);
          const session = getSession(req);
          if (body.action === "delete") {
            await dbPool.query("DELETE FROM academic_years WHERE id = $1", [body.id]);
            send(req, res, 200, { ok: true });
            return;
          }
          if (body.action === "set_active") {
            await dbPool.query("UPDATE academic_years SET is_active = false");
            await dbPool.query("UPDATE academic_years SET is_active = true WHERE id = $1", [body.id]);
            send(req, res, 200, { ok: true });
            return;
          }
          if (body.id) {
            await dbPool.query("UPDATE academic_years SET nama=$1, semester=$2, tanggal_mulai=$3, tanggal_selesai=$4 WHERE id=$5",
              [body.nama, body.semester, body.tanggal_mulai || null, body.tanggal_selesai || null, body.id]);
          } else {
            await dbPool.query("INSERT INTO academic_years (nama, semester, tanggal_mulai, tanggal_selesai, is_active) VALUES ($1,$2,$3,$4,$5)",
              [body.nama, body.semester || "Ganjil", body.tanggal_mulai || null, body.tanggal_selesai || null, body.is_active || false]);
          }
          await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
            [session?.id || "system", session?.name || "Admin", session?.role || "admin", "UPSERT", "academic_years", `Tahun Ajaran: ${body.nama}`]);
          send(req, res, 200, { ok: true });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // === API: API KEYS / MANAJEMEN INTEGRASI ===
    if (url.pathname.startsWith("/api/api-keys")) {
      if (!requireAdmin(req, res)) return;
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT id, service_name, service_label, is_active, extra_config, updated_at FROM api_keys ORDER BY service_name ASC");
          send(req, res, 200, { ok: true, data: rows });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        try {
          const body = await readJsonBody(req);
          const session = getSession(req);
          if (body.action === "delete") {
            await dbPool.query("DELETE FROM api_keys WHERE id = $1", [body.id]);
            send(req, res, 200, { ok: true });
            return;
          }
          const maskedKey = body.api_key ? body.api_key.substring(0, 6) + "****" : "";
          if (body.api_key === undefined) {
            await dbPool.query(
              `INSERT INTO api_keys (service_name, service_label, extra_config, is_active)
               VALUES ($1,$2,$3,$4)
               ON CONFLICT (service_name) DO UPDATE SET service_label=$2, extra_config=$3, is_active=$4, updated_at=CURRENT_TIMESTAMP`,
              [body.service_name, body.service_label || body.service_name, JSON.stringify(body.extra_config || {}), body.is_active !== false]
            );
          } else {
            await dbPool.query(
              `INSERT INTO api_keys (service_name, service_label, api_key, extra_config, is_active)
               VALUES ($1,$2,$3,$4,$5)
               ON CONFLICT (service_name) DO UPDATE SET service_label=$2, api_key=$3, extra_config=$4, is_active=$5, updated_at=CURRENT_TIMESTAMP`,
              [body.service_name, body.service_label || body.service_name, body.api_key || "", JSON.stringify(body.extra_config || {}), body.is_active !== false]
            );
          }
          await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
            [session?.id || "system", session?.name || "Admin", session?.role || "admin", "UPSERT", "api_keys", `API Key ${body.service_name}: ${maskedKey}`]);
          send(req, res, 200, { ok: true });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }
    // === API: GDRIVE MANUAL BACKUP ===
    if (url.pathname === "/api/backup-gdrive" && req.method === "POST") {
      if (!requireAdmin(req, res)) return;
      try {
        const { rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'google_drive' AND is_active = true LIMIT 1");
        if (rows.length === 0 || !rows[0].api_key) {
          send(req, res, 400, { ok: false, error: "Service Account Google Drive belum disetel/tidak aktif." });
          return;
        }
        let credentials;
        try {
          credentials = JSON.parse(rows[0].api_key);
        } catch (e) {
          send(req, res, 400, { ok: false, error: "Format kredensial Google Drive bukan JSON yang valid." });
          return;
        }

        const backupData = {};
        const tblResult = await dbPool.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'");
        const tables = tblResult.rows.map(r => r.tablename);
        for (const table of tables) {
          try {
            const result = await dbPool.query(`SELECT * FROM ${table}`);
            backupData[table] = result.rows;
          } catch (err) {}
        }

        const backupJsonStr = JSON.stringify(backupData, null, 2);
        const fileName = `Backup_Kurmon_Manual_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
        
        const auth = new google.auth.GoogleAuth({
          credentials,
          scopes: ['https://www.googleapis.com/auth/drive.file']
        });
        const drive = google.drive({ version: 'v3', auth });
        
        const fileMetadata = { name: fileName };
        if (rows[0].extra_config && rows[0].extra_config.folder_id) {
          fileMetadata.parents = [rows[0].extra_config.folder_id];
        }

        const response = await drive.files.create({
          requestBody: fileMetadata,
          media: { mimeType: 'application/json', body: backupJsonStr },
          fields: 'id, size',
          supportsAllDrives: true
        });

        const session = getSession(req);
        await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
          [session?.id || 'system', session?.name || 'Admin', session?.role || 'admin', 'GDRIVE_BACKUP_MANUAL', 'database', `Backup manual sukses. ID: ${response.data.id}`]);
        
        send(req, res, 200, { ok: true, data: { id: response.data.id, filename: fileName, size: (backupJsonStr.length / 1024 / 1024).toFixed(2) + ' MB' } });
      } catch (err) { 
        console.error("Manual Backup Error:", err);
        send(req, res, 500, { ok: false, error: err.message }); 
      }
      return;
    }

    // === API: TELEGRAM MANUAL BACKUP ===
    if (req.method === "POST" && url.pathname === "/api/backup-telegram") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      if (!["admin", "superadmin"].includes(normalizeServerRole(session.role))) {
        send(req, res, 403, { ok: false, error: "Akses ditolak" });
        return;
      }
      try {
        const { rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'telegram_backup' AND is_active = true LIMIT 1");
        if (rows.length === 0 || !rows[0].api_key || !rows[0].extra_config?.chat_id) {
          send(req, res, 400, { ok: false, error: "Telegram Backup belum dikonfigurasi atau tidak aktif (Bot Token & Chat ID wajib diisi)." });
          return;
        }

        const botToken = rows[0].api_key;
        const chatId = rows[0].extra_config.chat_id;

        const backupData = {};
        const tblResult = await dbPool.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'");
        const tables = tblResult.rows.map(r => r.tablename);
        
        for (const table of tables) {
          try {
            const result = await dbPool.query(`SELECT * FROM ${table}`);
            backupData[table] = result.rows;
          } catch (err) {}
        }

        const backupJsonStr = JSON.stringify(backupData, null, 2);
        const fileName = `Backup_Kurmon_Manual_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
        
        const boundary = "----KurmonBackupBoundary" + Date.now().toString(16);
        let multipartBody = "--" + boundary + "\r\n";
        multipartBody += `Content-Disposition: form-data; name="chat_id"\r\n\r\n${chatId}\r\n`;
        multipartBody += "--" + boundary + "\r\n";
        multipartBody += `Content-Disposition: form-data; name="document"; filename="${fileName}"\r\n`;
        multipartBody += "Content-Type: application/json\r\n\r\n";
        multipartBody += backupJsonStr + "\r\n";
        multipartBody += "--" + boundary + "--\r\n";

        const telegramRes = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
          method: 'POST',
          headers: { 'Content-Type': `multipart/form-data; boundary=${boundary}` },
          body: Buffer.from(multipartBody, 'utf-8')
        });

        const telegramData = await telegramRes.json();
        
        if (!telegramData.ok) {
           throw new Error(telegramData.description || "Gagal mengirim ke Telegram");
        }

        await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
          [session.id, session.name, session.role, 'TELEGRAM_BACKUP_MANUAL', 'database', `Backup manual sukses dikirim ke Telegram.`]);
        
        send(req, res, 200, { ok: true, data: { filename: fileName, size: (backupJsonStr.length / 1024 / 1024).toFixed(2) + ' MB' } });
      } catch (err) { 
        console.error("Manual Telegram Backup Error:", err);
        send(req, res, 500, { ok: false, error: err.message }); 
      }
      return;
    }

    // === API: RESTORE BACKUP ===
    if (req.method === "POST" && url.pathname === "/api/restore-backup") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      if (!["admin", "superadmin"].includes(normalizeServerRole(session.role))) {
        send(req, res, 403, { ok: false, error: "Akses ditolak" });
        return;
      }
      try {
        let bodyStr = "";
        for await (const chunk of req) bodyStr += chunk;
        const backupData = JSON.parse(bodyStr);

        const client = await dbPool.connect();
        try {
          await client.query("BEGIN");
          await client.query("SET session_replication_role = 'replica';"); // Disable triggers (FK constraints)

          const tables = Object.keys(backupData);
          for (const table of tables) {
            await client.query(`TRUNCATE TABLE ${table} CASCADE`);
          }

          for (const table of tables) {
            const rows = backupData[table];
            if (rows.length === 0) continue;
            
            const columns = Object.keys(rows[0]);
            const colString = columns.join(', ');
            
            for (let i = 0; i < rows.length; i++) {
               const row = rows[i];
               const values = columns.map(c => row[c] === undefined ? null : row[c]);
               const placeholders = columns.map((_, idx) => `${idx + 1}`).join(', ');
               await client.query(`INSERT INTO ${table} (${colString}) VALUES (${placeholders})`, values);
            }
          }

          await client.query("SET session_replication_role = 'origin';");
          await client.query("COMMIT");
          
          await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
            [session.id, session.name, session.role, 'RESTORE_BACKUP', 'database', `Database berhasil dipulihkan dari file JSON.`]);
          
          send(req, res, 200, { ok: true });
        } catch (dbErr) {
          await client.query("ROLLBACK");
          await client.query("SET session_replication_role = 'origin';");
          throw dbErr;
        } finally {
          client.release();
        }
      } catch (err) {
        console.error("Restore Error:", err);
        send(req, res, 500, { ok: false, error: err.message });
      }
      return;
    }

    // === API: CLOUDFLARE R2 MANUAL BACKUP ===
    if (req.method === "POST" && url.pathname === "/api/backup-r2") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      if (!["admin", "superadmin"].includes(normalizeServerRole(session.role))) {
        send(req, res, 403, { ok: false, error: "Akses ditolak" });
        return;
      }
      try {
        const { rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'cloudflare_r2' AND is_active = true LIMIT 1");
        if (rows.length === 0 || !rows[0].api_key || !rows[0].extra_config?.endpoint || !rows[0].extra_config?.bucket) {
          send(req, res, 400, { ok: false, error: "Cloudflare R2 Backup belum dikonfigurasi lengkap." });
          return;
        }

        let credentials;
        try {
          credentials = JSON.parse(rows[0].api_key); // { accessKeyId, secretAccessKey }
          if (!credentials.accessKeyId || !credentials.secretAccessKey) throw new Error("Missing keys");
        } catch (err) {
          send(req, res, 400, { ok: false, error: "Cloudflare R2 Backup gagal: Kredensial API Key tidak valid. Format harus JSON berisi accessKeyId dan secretAccessKey." });
          return;
        }
        const endpoint = rows[0].extra_config.endpoint;
        const bucket = rows[0].extra_config.bucket;

        const backupData = {};
        const tblResult = await dbPool.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'");
        const tables = tblResult.rows.map(r => r.tablename);
        
        for (const table of tables) {
          try {
            const result = await dbPool.query(`SELECT * FROM ${table}`);
            backupData[table] = result.rows;
          } catch (err) {}
        }

        const backupJsonStr = JSON.stringify(backupData, null, 2);
        const fileName = `Backup_Kurmon_Manual_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
        
        const s3 = new S3Client({
          region: "auto",
          endpoint: endpoint,
          credentials: {
            accessKeyId: credentials.accessKeyId,
            secretAccessKey: credentials.secretAccessKey,
          },
        });

        await s3.send(new PutObjectCommand({
          Bucket: bucket,
          Key: fileName,
          Body: backupJsonStr,
          ContentType: "application/json",
        }));

        await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
          [session.id, session.name, session.role, 'R2_BACKUP_MANUAL', 'database', `Backup manual sukses dikirim ke Cloudflare R2.`]);
        
        send(req, res, 200, { ok: true, data: { filename: fileName, size: (backupJsonStr.length / 1024 / 1024).toFixed(2) + ' MB' } });
      } catch (err) { 
        console.error("Manual R2 Backup Error:", err);
        send(req, res, 500, { ok: false, error: err.message }); 
      }
      return;
    }

    // === API: ARCHIVE & PURGE OLD DATA ===
    if (req.method === "POST" && url.pathname === "/api/archive-data") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      if (!["admin", "superadmin"].includes(normalizeServerRole(session.role))) {
        send(req, res, 403, { ok: false, error: "Akses ditolak" });
        return;
      }
      
      try {
        let bodyStr = "";
        for await (const chunk of req) bodyStr += chunk;
        const payload = JSON.parse(bodyStr);
        const { dateBefore } = payload;
        
        if (!dateBefore) {
          send(req, res, 400, { ok: false, error: "Parameter dateBefore dibutuhkan" });
          return;
        }

        const targetTables = [
          { name: 'attendances', col: 'created_at' },
          { name: 'hikvision_logs', col: 'created_at' },
          { name: 'audit_logs', col: 'created_at' },
          { name: 'whatsapp_logs', col: 'sent_at' },
          { name: 'login_logs', col: 'created_at' }
        ];
        const archiveData = {};
        
        for (const table of targetTables) {
          try {
            const result = await dbPool.query(`SELECT * FROM ${table.name} WHERE ${table.col} < $1`, [dateBefore]);
            archiveData[table.name] = result.rows;
          } catch (err) {
            console.error(`Skip archiving ${table.name}: `, err.message);
          }
        }

        const totalArchivedRows = Object.values(archiveData).reduce((sum, arr) => sum + arr.length, 0);
        if (totalArchivedRows === 0) {
           send(req, res, 400, { ok: false, error: "Tidak ada data lawas yang perlu dibersihkan." });
           return;
        }

        const archiveJsonStr = JSON.stringify(archiveData, null, 2);
        const fileName = `Archive_Kurmon_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
        
        // 1. TRY UPLOAD TO R2 FIRST
        let uploadSuccess = false;
        let uploadedTo = "";

        const { rows: r2Rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'cloudflare_r2' AND is_active = true LIMIT 1");
        if (r2Rows.length > 0 && r2Rows[0].api_key) {
           try {
             const creds = JSON.parse(r2Rows[0].api_key);
             const s3 = new S3Client({
                region: "auto",
                endpoint: r2Rows[0].extra_config.endpoint,
                credentials: { accessKeyId: creds.accessKeyId, secretAccessKey: creds.secretAccessKey },
             });
             await s3.send(new PutObjectCommand({ Bucket: r2Rows[0].extra_config.bucket, Key: fileName, Body: archiveJsonStr, ContentType: "application/json" }));
             uploadSuccess = true;
             uploadedTo = "Cloudflare R2";
           } catch(e) { console.error("R2 Upload failed:", e); }
        }

        // 2. TRY TELEGRAM IF R2 FAILS
        if (!uploadSuccess) {
           const { rows: tgRows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'telegram_backup' AND is_active = true LIMIT 1");
           if (tgRows.length > 0 && tgRows[0].api_key) {
              try {
                const boundary = "----KurmonArchiveBoundary" + Date.now().toString(16);
                let multipartBody = "--" + boundary + "\r\n";
                multipartBody += `Content-Disposition: form-data; name="chat_id"\r\n\r\n${tgRows[0].extra_config?.chat_id || ''}\r\n`;
                multipartBody += "--" + boundary + "\r\n";
                multipartBody += `Content-Disposition: form-data; name="document"; filename="${fileName}"\r\n`;
                multipartBody += "Content-Type: application/json\r\n\r\n";
                multipartBody += archiveJsonStr + "\r\n";
                multipartBody += "--" + boundary + "--\r\n";

                const tgRes = await fetch(`https://api.telegram.org/bot${tgRows[0].api_key}/sendDocument`, {
                  method: 'POST',
                  headers: { 'Content-Type': `multipart/form-data; boundary=${boundary}` },
                  body: Buffer.from(multipartBody, 'utf-8')
                });
                const tgData = await tgRes.json();
                if (tgData.ok) { uploadSuccess = true; uploadedTo = "Telegram"; }
              } catch(e) { console.error("TG Upload failed:", e); }
           }
        }

        if (!uploadSuccess) {
           send(req, res, 500, { ok: false, error: "Gagal mengunggah arsip ke Cloud (R2/Telegram tidak aktif atau error). Pembersihan dibatalkan untuk mencegah kehilangan data." });
           return;
        }

        // DELETION PHASE (ONLY AFTER SAFE UPLOAD)
        const client = await dbPool.connect();
        try {
          await client.query("BEGIN");
          for (const table of targetTables) {
             try {
               await client.query(`DELETE FROM ${table.name} WHERE ${table.col} < $1`, [dateBefore]);
             } catch (err) {}
          }
          await client.query("COMMIT");
        } catch(e) {
          await client.query("ROLLBACK");
          throw e;
        } finally {
          client.release();
        }

        await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
          [session.id, session.name, session.role, 'ARCHIVE_DATA', 'database', `Pembersihan berhasil. ${totalArchivedRows} baris dihapus & diamankan di ${uploadedTo}`]);
        
        send(req, res, 200, { ok: true, message: `${totalArchivedRows} data berhasil dibersihkan dan diarsipkan ke ${uploadedTo}!` });
      } catch (err) { 
        console.error("Archive Error:", err);
        send(req, res, 500, { ok: false, error: err.message }); 
      }
      return;
    }

    // === API: AUDIT LOGS ===
    if (url.pathname.startsWith("/api/audit-logs")) {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      
      const isUserAdmin = ["admin", "superadmin"].includes(normalizeServerRole(session.role));
      let isAllowed = isUserAdmin;
      if (!isAllowed) {
        try {
          const payload = await readMainPayload();
          const roleKey = session.role === "waka" ? `waka_${session.division || "kurikulum"}` : session.role;
          const perms = payload?.rolePermissions?.[roleKey];
          if (perms) {
            if (Array.isArray(perms)) {
              isAllowed = perms.includes("audit_log");
            } else {
              const level = perms["audit_log"];
              isAllowed = level && level !== "none" && level !== "nonaktif";
            }
          }
        } catch (e) { console.error("Error checking role permissions for audit_log:", e); }
      }
      if (!isAllowed) return send(req, res, 403, { ok: false, error: "Akses ditolak" });

      if (req.method === "GET") {
        try {
          const page = parseInt(url.searchParams?.get("page") || "1");
          const limit = parseInt(url.searchParams?.get("limit") || "50");
          const offset = (page - 1) * limit;
          
          let query = "SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT $1 OFFSET $2";
          let countQuery = "SELECT COUNT(*) FROM audit_logs";
          let params = [limit, offset];
          let countParams = [];

          if (!isUserAdmin) {
            query = "SELECT * FROM audit_logs WHERE NOT (user_role IN ('admin', 'superadmin') AND action = 'LOGIN') ORDER BY created_at DESC LIMIT $1 OFFSET $2";
            countQuery = "SELECT COUNT(*) FROM audit_logs WHERE NOT (user_role IN ('admin', 'superadmin') AND action = 'LOGIN')";
          }

          const { rows } = await dbPool.query(query, params);
          const countRes = await dbPool.query(countQuery, countParams);
          send(req, res, 200, { ok: true, data: rows, total: parseInt(countRes.rows[0].count) });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        try {
          const body = await readJsonBody(req);
          if (body.action === "clear") {
            await dbPool.query("DELETE FROM audit_logs");
            send(req, res, 200, { ok: true });
            return;
          }
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // === API: KARTU PELAJAR TEMPLATES ===
    if (url.pathname.startsWith("/api/student-cards")) {
      if (!requireAuthenticated(req, res)) return;
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT * FROM student_card_templates ORDER BY is_default DESC, id ASC");
          send(req, res, 200, { ok: true, data: rows });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        if (!requireAdmin(req, res)) return;
        try {
          const body = await readJsonBody(req);
          if (body.action === "delete") {
            await dbPool.query("DELETE FROM student_card_templates WHERE id = $1", [body.id]);
          } else if (body.id) {
            await dbPool.query("UPDATE student_card_templates SET name=$1, config=$2, is_default=$3 WHERE id=$4",
              [body.name, JSON.stringify(body.config || {}), body.is_default || false, body.id]);
          } else {
            await dbPool.query("INSERT INTO student_card_templates (name, config, is_default) VALUES ($1,$2,$3)",
              [body.name, JSON.stringify(body.config || {}), body.is_default || false]);
          }
          send(req, res, 200, { ok: true });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // === API: WHATSAPP (Fonnte Gateway) ===
    if (url.pathname === "/api/whatsapp/send") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        const session = getSession(req);
        const keyRes = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'whatsapp_fonnte' AND is_active = true");
        if (keyRes.rowCount === 0) {
          send(req, res, 400, { ok: false, error: "API Key WhatsApp belum dikonfigurasi atau tidak aktif. Masuk ke menu Manajemen API Key." });
          return;
        }
        const token = keyRes.rows[0].api_key;
        const phoneRaw = String(body.phone || "").replace(/\D/g, "");
        const phone = phoneRaw.startsWith("0") ? "62" + phoneRaw.slice(1) : phoneRaw;
        if (!phone || !body.message) {
          send(req, res, 400, { ok: false, error: "Nomor HP dan pesan wajib diisi." });
          return;
        }
        let responseData = {};
        let status = "sent";
        try {
          const fonnteRes = await fetch("https://api.fonnte.com/send", {
            method: "POST",
            headers: { "Authorization": token, "Content-Type": "application/json" },
            body: JSON.stringify({ target: phone, message: body.message, countryCode: "62" })
          });
          responseData = await fonnteRes.json();
          if (!fonnteRes.ok || responseData.status === false) status = "failed";
        } catch (e) {
          status = "failed";
          responseData = { error: e.message };
        }
        await dbPool.query("INSERT INTO whatsapp_logs (phone, recipient_name, message, status, trigger_type, response_data) VALUES ($1,$2,$3,$4,$5,$6)",
          [phone, body.recipient_name || "", body.message, status, body.trigger_type || "manual", JSON.stringify(responseData)]);
        await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
          [session?.id || "system", session?.name || "System", session?.role || "admin", "SEND_WA", "whatsapp", `Kirim WA ke ${phone} (${body.recipient_name || ""}): ${status}`]);
        send(req, res, 200, { ok: status === "sent", status, data: responseData });
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }

    // === API: WHATSAPP LOGS ===
    if (url.pathname === "/api/whatsapp/logs") {
      if (!requireAdmin(req, res)) return;
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT * FROM whatsapp_logs ORDER BY sent_at DESC LIMIT 200");
          send(req, res, 200, { ok: true, data: rows });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // === API: WHATSAPP SEND REKAP (GURU & SISWA) ===
    if (url.pathname === "/api/whatsapp/send-rekap") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        const { target, type, month, year, date } = body;
        const session = getSession(req);

        const keyRes = await dbPool.query("SELECT api_key FROM api_keys WHERE service_name = 'whatsapp_fonnte' AND is_active = true");
        if (keyRes.rowCount === 0) {
          send(req, res, 400, { ok: false, error: "API Key WhatsApp belum dikonfigurasi atau tidak aktif. Masuk ke menu Manajemen API Key." });
          return;
        }
        const token = keyRes.rows[0].api_key;

        const mainRes = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'main_store'");
        const mainData = mainRes.rowCount > 0 ? JSON.parse(mainRes.rows[0].data) : {};
        const attendanceRecords = Array.isArray(mainData.attendanceRecords) ? mainData.attendanceRecords : [];

        if (target === "guru") {
          const conf = await getHikvisionConfig();
          const notifyRole = conf.notify_role || "none";
          let recipientPhone = "";
          let recipientName = "Pengawas Absensi";

          if (notifyRole === "custom" && conf.notify_custom_phone) {
            recipientPhone = String(conf.notify_custom_phone).replace(/\D/g, "");
          } else if (notifyRole !== "none") {
            let roleQuery = "";
            if (notifyRole === "kepsek") {
              roleQuery = "SELECT payload FROM mst_teachers WHERE payload->>'role' = 'kepsek' LIMIT 1";
            } else if (notifyRole === "waka_kurikulum") {
              roleQuery = "SELECT payload FROM mst_teachers WHERE payload->>'role' = 'waka' AND payload->>'division' = 'kurikulum' LIMIT 1";
            } else if (notifyRole === "waka_kesiswaan") {
              roleQuery = "SELECT payload FROM mst_teachers WHERE payload->>'role' = 'waka' AND payload->>'division' = 'kesiswaan' LIMIT 1";
            }

            if (roleQuery) {
              const roleRes = await dbPool.query(roleQuery);
              if (roleRes.rowCount > 0) {
                const targetTeacher = roleRes.rows[0].payload;
                recipientPhone = String(targetTeacher.phone || "").replace(/\D/g, "");
                recipientName = targetTeacher.name || "Pihak Sekolah";
              }
            }
          }

          if (!recipientPhone) {
            send(req, res, 400, { ok: false, error: "Nomor WhatsApp Pengawas belum dikonfigurasi di Pengaturan Mesin." });
            return;
          }
          const destPhone = recipientPhone.startsWith("0") ? "62" + recipientPhone.slice(1) : recipientPhone;

          const teachersRes = await dbPool.query("SELECT id, payload FROM mst_teachers");
          const teachers = teachersRes.rows.map(r => r.payload);

          let message = "";

          if (type === "daily") {
            const targetDate = date || new Date().toISOString().split('T')[0];
            const records = attendanceRecords.filter(r => r.date === targetDate);

            const absentList = [];
            let hadirCount = 0;
            let telatCount = 0;

            teachers.forEach(t => {
              const code = t.code;
              const recs = records.filter(r => r.teacherCode === code);
              if (recs.length === 0) {
                absentList.push({ name: t.name, status: "Alpa", note: "Tidak ada keterangan" });
              } else {
                const hasLate = recs.some(r => r.status === "Terlambat");
                const hasIzin = recs.some(r => r.status === "Izin");
                const hasSakit = recs.some(r => r.status === "Sakit");
                const hasDinas = recs.some(r => r.status === "Dinas Luar");

                if (hasIzin) absentList.push({ name: t.name, status: "Izin", note: recs.find(r => r.status === "Izin").note });
                else if (hasSakit) absentList.push({ name: t.name, status: "Sakit", note: recs.find(r => r.status === "Sakit").note });
                else if (hasDinas) absentList.push({ name: t.name, status: "Dinas Luar", note: recs.find(r => r.status === "Dinas Luar").note });
                else if (hasLate) {
                  telatCount++;
                  hadirCount++;
                } else {
                  hadirCount++;
                }
              }
            });

            message = `📝 REKAP HARIAN KEHADIRAN GURU\n`;
            message += `Tanggal: ${targetDate}\n\n`;
            message += `✅ Hadir Tepat Waktu: ${hadirCount - telatCount} orang\n`;
            message += `⏰ Terlambat: ${telatCount} orang\n`;
            message += `❌ Tidak Hadir: ${absentList.length} orang\n\n`;
            message += `Daftar Keterangan:\n`;
            if (absentList.length === 0) {
              message += `- Semua guru hadir/tercatat.\n`;
            } else {
              absentList.forEach((a, i) => {
                message += `${i + 1}. ${a.name} (${a.status}) ${a.note ? ` - ${a.note}` : ''}\n`;
              });
            }
            message += `\nNotifikasi otomatis Kurmon.`;
          } else {
            const targetMonth = parseInt(month || new Date().getMonth() + 1);
            const targetYear = parseInt(year || new Date().getFullYear());
            const daysInMonth = new Date(targetYear, targetMonth, 0).getDate();

            message = `📅 REKAP BULANAN KEHADIRAN GURU\n`;
            message += `Bulan: ${targetMonth}/${targetYear}\n\n`;

            teachers.slice(0, 15).forEach((t, idx) => {
              const code = t.code;
              let hadir = 0, sakit = 0, izin = 0, alpa = 0, telat = 0;
              for (let d = 1; d <= daysInMonth; d++) {
                const dateStr = `${targetYear}-${String(targetMonth).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                const recs = attendanceRecords.filter(r => r.teacherCode === code && r.date === dateStr);
                if (recs.length > 0) {
                  if (recs.some(r => r.status === "Izin")) izin++;
                  else if (recs.some(r => r.status === "Sakit")) sakit++;
                  else if (recs.some(r => r.status === "Dinas Luar")) hadir++;
                  else if (recs.some(r => r.status === "Terlambat")) { hadir++; telat++; }
                  else hadir++;
                } else {
                  const dayOfWeek = new Date(targetYear, targetMonth - 1, d).getDay();
                  if (dayOfWeek !== 0 && dayOfWeek !== 6) alpa++;
                }
              }
              message += `${idx + 1}. ${t.name}:\n   Hadir: ${hadir} | Telat: ${telat} | Izin: ${izin} | Sakit: ${sakit} | Alpa: ${alpa}\n`;
            });
            if (teachers.length > 15) {
              message += `... dan ${teachers.length - 15} guru lainnya.`;
            }
          }

          const fonnteRes = await fetch("https://api.fonnte.com/send", {
            method: "POST",
            headers: { "Authorization": token, "Content-Type": "application/json" },
            body: JSON.stringify({ target: destPhone, message: message, countryCode: "62" })
          });
          const resData = await fonnteRes.json();
          const waStatus = (fonnteRes.ok && resData.status !== false) ? "sent" : "failed";

          await dbPool.query("INSERT INTO whatsapp_logs (phone, recipient_name, message, status, trigger_type, response_data) VALUES ($1,$2,$3,$4,$5,$6)",
            [destPhone, recipientName, message, waStatus, `rekap_guru_${type}`, JSON.stringify(resData)]);
          
          send(req, res, 200, { ok: waStatus === "sent", status: waStatus, message: `Rekap ${type} guru berhasil dikirim ke ${recipientName}` });
          return;
        } else {
          // SISWA
          if (type === "daily") {
            const targetDate = date || new Date().toISOString().split('T')[0];
            const walasRes = await dbPool.query("SELECT payload FROM mst_teachers WHERE payload->>'role' = 'walas' OR payload->>'isWalas' = 'true'");
            const walasList = walasRes.rows.map(r => r.payload);

            const studentsRes = await dbPool.query("SELECT payload FROM mst_students");
            const students = studentsRes.rows.map(r => r.payload);

            let sentCount = 0;

            for (const walas of walasList) {
              const className = walas.walasClass;
              const walasPhoneRaw = String(walas.phone || "").replace(/\D/g, "");
              if (!className || !walasPhoneRaw) continue;

              const classStudents = students.filter(s => s.className === className || s.class_name === className);
              const absentStudents = [];

              classStudents.forEach(s => {
                const recs = attendanceRecords.filter(r => r.siswaNis === s.nis && r.date === targetDate);
                if (recs.length > 0) {
                  const isAbsent = recs.some(r => ["Izin", "Sakit", "Alpa"].includes(r.status));
                  if (isAbsent) {
                    const rec = recs.find(r => ["Izin", "Sakit", "Alpa"].includes(r.status));
                    absentStudents.push({ name: s.namaSiswa || s.name, status: rec.status, note: rec.note || "" });
                  }
                }
              });

              if (absentStudents.length > 0) {
                const destPhone = walasPhoneRaw.startsWith("0") ? "62" + walasPhoneRaw.slice(1) : walasPhoneRaw;
                let classMsg = `📝 REKAP HARIAN ABSENSI SISWA\n`;
                classMsg += `Kelas: ${className}\n`;
                classMsg += `Wali Kelas: ${walas.name}\n`;
                classMsg += `Tanggal: ${targetDate}\n\n`;
                classMsg += `Daftar Siswa Tidak Hadir:\n`;
                absentStudents.forEach((st, i) => {
                  classMsg += `${i + 1}. ${st.name} (${st.status})${st.note ? ` - ${st.note}` : ''}\n`;
                });
                classMsg += `\nMohon ditindaklanjuti. Terima kasih.`;

                try {
                  const fonnteRes = await fetch("https://api.fonnte.com/send", {
                    method: "POST",
                    headers: { "Authorization": token, "Content-Type": "application/json" },
                    body: JSON.stringify({ target: destPhone, message: classMsg, countryCode: "62" })
                  });
                  const resData = await fonnteRes.json();
                  const waStatus = (fonnteRes.ok && resData.status !== false) ? "sent" : "failed";
                  if (waStatus === "sent") sentCount++;

                  await dbPool.query("INSERT INTO whatsapp_logs (phone, recipient_name, message, status, trigger_type, response_data) VALUES ($1,$2,$3,$4,$5,$6)",
                    [destPhone, walas.name, classMsg, waStatus, "rekap_siswa_harian", JSON.stringify(resData)]);
                } catch (e) {
                  console.error(`Gagal kirim rekap ke walas ${className}:`, e.message);
                }
              }
            }

            send(req, res, 200, { ok: true, message: `Rekap harian siswa selesai dikirim ke ${sentCount} wali kelas.` });
            return;
          } else {
            const targetMonth = parseInt(month || new Date().getMonth() + 1);
            const targetYear = parseInt(year || new Date().getFullYear());

            const studentsRes = await dbPool.query("SELECT payload FROM mst_students");
            const students = studentsRes.rows.map(r => r.payload);

            let sentCount = 0;

            for (const s of students.slice(0, 30)) {
              const parentPhoneRaw = String(s.phone || s.wa_ortu || "").replace(/\D/g, "");
              if (!parentPhoneRaw) continue;

              const recs = attendanceRecords.filter(r => r.siswaNis === s.nis && r.date.startsWith(`${targetYear}-${String(targetMonth).padStart(2, '0')}`));
              let hadir = 0, sakit = 0, izin = 0, alpa = 0;
              recs.forEach(r => {
                if (r.status === "Izin") izin++;
                else if (r.status === "Sakit") sakit++;
                else if (r.status === "Alpa") alpa++;
                else hadir++;
              });

              const destPhone = parentPhoneRaw.startsWith("0") ? "62" + parentPhoneRaw.slice(1) : parentPhoneRaw;
              const parentMsg = `📅 REKAP ABSENSI SISWA (BULANAN)\n` +
                `Nama Siswa: ${s.namaSiswa || s.name}\n` +
                `Kelas: ${s.class_name || s.className || "-"}\n` +
                `Bulan: ${targetMonth}/${targetYear}\n\n` +
                `Ringkasan Kehadiran:\n` +
                `- Hadir: ${hadir} hari\n` +
                `- Sakit: ${sakit} hari\n` +
                `- Izin: ${izin} hari\n` +
                `- Alpa: ${alpa} hari\n\n` +
                `Terima kasih atas kerja samanya. - Pihak Sekolah`;

              try {
                const fonnteRes = await fetch("https://api.fonnte.com/send", {
                  method: "POST",
                  headers: { "Authorization": token, "Content-Type": "application/json" },
                  body: JSON.stringify({ target: destPhone, message: parentMsg, countryCode: "62" })
                });
                const resData = await fonnteRes.json();
                const waStatus = (fonnteRes.ok && resData.status !== false) ? "sent" : "failed";
                if (waStatus === "sent") sentCount++;

                await dbPool.query("INSERT INTO whatsapp_logs (phone, recipient_name, message, status, trigger_type, response_data) VALUES ($1,$2,$3,$4,$5,$6)",
                  [destPhone, s.namaSiswa || s.name, parentMsg, waStatus, "rekap_siswa_bulanan", JSON.stringify(resData)]);
              } catch (e) {
                console.error(`Gagal kirim rekap bulanan ke ortu ${s.nis}:`, e.message);
              }
            }

            send(req, res, 200, { ok: true, message: `Rekap bulanan siswa dikirim ke ${sentCount} nomor orang tua.` });
            return;
          }
        }
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }

    // === API: E-SURAT TEMPLATES ===
    if (url.pathname.startsWith("/api/esurat")) {
      if (!requireAuthenticated(req, res)) return;
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT * FROM esurat_templates ORDER BY jenis ASC, id ASC");
          send(req, res, 200, { ok: true, data: rows });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        if (!requireAdmin(req, res)) return;
        try {
          const body = await readJsonBody(req);
          if (body.action === "delete") {
            await dbPool.query("DELETE FROM esurat_templates WHERE id = $1", [body.id]);
          } else if (body.id) {
            await dbPool.query("UPDATE esurat_templates SET jenis=$1, nama=$2, isi_template=$3 WHERE id=$4",
              [body.jenis, body.nama, body.isi_template || "", body.id]);
          } else {
            await dbPool.query("INSERT INTO esurat_templates (jenis, nama, isi_template) VALUES ($1,$2,$3)",
              [body.jenis, body.nama, body.isi_template || ""]);
          }
          send(req, res, 200, { ok: true });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // === API: KENAIKAN KELAS ===
    if (url.pathname.startsWith("/api/kenaikan-kelas")) {
      if (!requireAdmin(req, res)) return;
      if (req.method === "GET") {
        try {
          const { rows } = await dbPool.query("SELECT * FROM kenaikan_kelas_log ORDER BY tanggal_proses DESC LIMIT 20");
          send(req, res, 200, { ok: true, data: rows });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
      if (req.method === "POST") {
        try {
          const body = await readJsonBody(req);
          const session = getSession(req);
          const detail = body.detail || [];
          
          const jumlahNaik = detail.filter(d => d.action === "naik").length;
          const jumlahLulus = detail.filter(d => d.action === "lulus").length;
          await dbPool.query(
            "INSERT INTO kenaikan_kelas_log (tahun_ajaran, jumlah_naik, jumlah_lulus, detail, processed_by) VALUES ($1,$2,$3,$4,$5)",
            [body.tahun_ajaran || "Unknown", jumlahNaik, jumlahLulus, JSON.stringify(detail), session?.name || "Admin"]
          );
          await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
            [session?.id || "system", session?.name || "Admin", session?.role || "admin", "KENAIKAN_KELAS", "students", `Naik: ${jumlahNaik}, Lulus: ${jumlahLulus}, TA: ${body.tahun_ajaran}`]);

          const payload = await readMainPayload();
          let dbStudents = [];
          try {
            const res = await dbPool.query('SELECT payload FROM mst_students');
            if (res.rows.length > 0) dbStudents = res.rows.map(r => r.payload);
          } catch(e) {}
          
          const studentsToUse = dbStudents.length > 0 ? dbStudents : (payload.students || []);

          if (Array.isArray(studentsToUse)) {
            const getNextGrade = (g) => {
              const GRADE_ORDER = ['X', 'XI', 'XII'];
              const idx = GRADE_ORDER.indexOf(g.toUpperCase());
              if (idx < 0 || idx >= GRADE_ORDER.length - 1) return null;
              return GRADE_ORDER[idx + 1];
            };
            
            // Create a lookup for O(1)
            const detailMap = {};
            for (const d of detail) detailMap[d.nis] = d.action;
            
            let changed = false;
            payload.students = payload.students.map(s => {
              const action = detailMap[s.nis];
              if (action === 'naik') {
                const newClass = s.class_name.replace(/^(X{1,3}|XI|XII)/i, (m) => getNextGrade(m) || m);
                s.class_name = newClass;
                changed = true;
              } else if (action === 'lulus') {
                s.class_name = `LULUS ${body.tahun_ajaran}`;
                changed = true;
              }
              return s;
            });
            
            if (changed) {
              if (dbStudents.length > 0) {
          const client = await dbPool.connect();
          try {
            await client.query('BEGIN');
            await client.query('DELETE FROM mst_students');
            for (const item of studentsToUse) {
              await client.query('INSERT INTO mst_students (id, payload) VALUES ($1, $2)', [String(item.nis || Math.random()), JSON.stringify(item)]);
            }
            await client.query('COMMIT');
          } catch(e) {
            await client.query('ROLLBACK');
          } finally {
            client.release();
          }
        } else {
          payload.students = studentsToUse;
          await writeMainPayload(payload);
        }
            }
          }

          send(req, res, 200, { ok: true });
        } catch (err) { sendDatabaseError(req, res, err); }
        return;
      }
    }

    // Catch-all 404 for unknown routes
    send(req, res, 404, { ok: false, error: "Not Found" });

  } catch (error) {
    console.error("Auth server error:", error);
    send(req, res, 500, { ok: false, error: error.message || "Internal server error" });
  }
});

// ==================== HIKVISION SYNC CRON ====================
cron.schedule('*/5 * * * *', () => {
  pullHikvisionLogs().catch(console.error);
});

cron.schedule('0 12 * * *', () => {
  console.log("[CRON] Mengirim Rekap Harian ke Wali Kelas...");
  sendDailyClassSummary().catch(console.error);
});

// ==================== GOOGLE DRIVE BACKUP CRON ====================
cron.schedule('0 2 * * *', async () => {
  console.log("[CRON] Memulai otomatisasi Google Drive Backup...");
  try {
    const { rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'google_drive' AND is_active = true LIMIT 1");
    if (rows.length === 0 || !rows[0].api_key) {
      console.log("[CRON] Batal backup: Service Account Google Drive belum disetel/tidak aktif.");
      return;
    }
    
    let credentials;
    try {
      credentials = JSON.parse(rows[0].api_key);
    } catch (e) {
      console.log("[CRON] Batal backup: Format kredensial Google Drive bukan JSON yang valid.");
      return;
    }

    const backupData = {};
    const tblResult = await dbPool.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'");
        const tables = tblResult.rows.map(r => r.tablename);
    
    for (const table of tables) {
      try {
        const result = await dbPool.query(`SELECT * FROM ${table}`);
        backupData[table] = result.rows;
      } catch (err) {}
    }

    const backupJsonStr = JSON.stringify(backupData, null, 2);
    const fileName = `Backup_Kurmon_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    
    const auth = new google.auth.GoogleAuth({
      credentials,
      scopes: ['https://www.googleapis.com/auth/drive.file']
    });
    const drive = google.drive({ version: 'v3', auth });
    
    const fileMetadata = { name: fileName };
    if (rows[0].extra_config && rows[0].extra_config.folder_id) {
      fileMetadata.parents = [rows[0].extra_config.folder_id];
    }
    
    const response = await drive.files.create({
      requestBody: fileMetadata,
      media: { mimeType: 'application/json', body: backupJsonStr },
      fields: 'id'
    });
    
    console.log(`[CRON] Backup berhasil. File ID: ${response.data.id}`);
    await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
      ['system', 'Sistem Cron', 'system', 'GDRIVE_BACKUP', 'database', `Backup harian otomatis sukses. ID: ${response.data.id}`]);

  } catch (error) {
    console.error("[CRON] Google Drive Backup Error:", error);
    await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
      ['system', 'Sistem Cron', 'system', 'GDRIVE_BACKUP_ERROR', 'database', `Backup harian gagal: ${error.message}`]);
  }
}, { timezone: "Asia/Jakarta" });

// ==================== TELEGRAM BACKUP CRON ====================
cron.schedule('0 2 * * *', async () => {
  console.log("[CRON] Memulai otomatisasi Telegram Backup...");
  try {
    const { rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'telegram_backup' AND is_active = true LIMIT 1");
    if (rows.length === 0 || !rows[0].api_key || !rows[0].extra_config?.chat_id) {
      console.log("[CRON] Batal backup: Telegram Backup belum dikonfigurasi atau tidak aktif.");
      return;
    }
    
    const botToken = rows[0].api_key;
    const chatId = rows[0].extra_config.chat_id;

    const backupData = {};
    const tblResult = await dbPool.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'");
    const tables = tblResult.rows.map(r => r.tablename);
    
    for (const table of tables) {
      try {
        const result = await dbPool.query(`SELECT * FROM ${table}`);
        backupData[table] = result.rows;
      } catch (err) {}
    }

    const backupJsonStr = JSON.stringify(backupData, null, 2);
    const fileName = `Backup_Kurmon_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    
    const boundary = "----KurmonBackupBoundary" + Date.now().toString(16);
    let multipartBody = "--" + boundary + "\r\n";
    multipartBody += `Content-Disposition: form-data; name="chat_id"\r\n\r\n${chatId}\r\n`;
    multipartBody += "--" + boundary + "\r\n";
    multipartBody += `Content-Disposition: form-data; name="document"; filename="${fileName}"\r\n`;
    multipartBody += "Content-Type: application/json\r\n\r\n";
    multipartBody += backupJsonStr + "\r\n";
    multipartBody += "--" + boundary + "--\r\n";

    const telegramRes = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
      method: 'POST',
      headers: { 'Content-Type': `multipart/form-data; boundary=${boundary}` },
      body: Buffer.from(multipartBody, 'utf-8')
    });

    const telegramData = await telegramRes.json();
    
    if (!telegramData.ok) {
       throw new Error(telegramData.description || "Gagal mengirim ke Telegram");
    }
    
    console.log(`[CRON] Backup Telegram berhasil.`);
    await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
      ['system', 'Sistem Cron', 'system', 'TELEGRAM_BACKUP', 'database', `Backup harian otomatis sukses dikirim ke Telegram.`]);

  } catch (error) {
    console.error("[CRON] Telegram Backup Error:", error);
    await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
      ['system', 'Sistem Cron', 'system', 'TELEGRAM_BACKUP_ERROR', 'database', `Backup harian gagal dikirim: ${error.message}`]);
  }
}, { timezone: "Asia/Jakarta" });

// ==================== CLOUDFLARE R2 BACKUP CRON ====================
cron.schedule('0 2 * * *', async () => {
  console.log("[CRON] Memulai otomatisasi Cloudflare R2 Backup...");
  try {
    const { rows } = await dbPool.query("SELECT api_key, extra_config FROM api_keys WHERE service_name = 'cloudflare_r2' AND is_active = true LIMIT 1");
    if (rows.length === 0 || !rows[0].api_key || !rows[0].extra_config?.endpoint || !rows[0].extra_config?.bucket) {
      console.log("[CRON] Batal backup: Cloudflare R2 belum dikonfigurasi atau tidak aktif.");
      return;
    }
    
    const credentials = JSON.parse(rows[0].api_key);
    const endpoint = rows[0].extra_config.endpoint;
    const bucket = rows[0].extra_config.bucket;

    const backupData = {};
    const tblResult = await dbPool.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'");
    const tables = tblResult.rows.map(r => r.tablename);
    
    for (const table of tables) {
      try {
        const result = await dbPool.query(`SELECT * FROM ${table}`);
        backupData[table] = result.rows;
      } catch (err) {}
    }

    const backupJsonStr = JSON.stringify(backupData, null, 2);
    const fileName = `Backup_Kurmon_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    
    const s3 = new S3Client({
      region: "auto",
      endpoint: endpoint,
      credentials: {
        accessKeyId: credentials.accessKeyId,
        secretAccessKey: credentials.secretAccessKey,
      },
    });

    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: fileName,
      Body: backupJsonStr,
      ContentType: "application/json",
    }));
    
    console.log(`[CRON] Backup Cloudflare R2 berhasil.`);
    await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
      ['system', 'Sistem Cron', 'system', 'R2_BACKUP', 'database', `Backup harian otomatis sukses dikirim ke Cloudflare R2.`]);

  } catch (error) {
    console.error("[CRON] Cloudflare R2 Backup Error:", error);
    await dbPool.query("INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1,$2,$3,$4,$5,$6)",
      ['system', 'Sistem Cron', 'system', 'R2_BACKUP_ERROR', 'database', `Backup harian gagal dikirim: ${error.message}`]);
  }
}, { timezone: "Asia/Jakarta" });

const PORT = Number.parseInt(process.env.AUTH_PORT || "4174", 10);
server.listen(PORT, AUTH_BIND_HOST, () => {
  console.log(`Auth server running on port ${PORT} (bind: ${AUTH_BIND_HOST})`);
});

// restarted
