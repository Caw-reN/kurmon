import { encryptPassword, decryptPassword } from '../hikvision-api.mjs';

export async function handleHikvisionRoutes(req, res, url, ctx) {
  const { dbPool, send, sendDatabaseError, requireAuthenticated, getSession, readJsonBody, readMainPayload, isMonitoringAdmin, isAdminRole } = ctx;


  async function getHikvisionConfig() {
    try {
      const res = await dbPool.query("SELECT config_data FROM app_settings WHERE module = 'hikvision' LIMIT 1");
      if (res.rowCount > 0) {
        return typeof res.rows[0].config_data === 'string' ? JSON.parse(res.rows[0].config_data) : res.rows[0].config_data;
      }
    } catch (e) {
      console.error("Error getHikvisionConfig:", e);
    }
    return {};
  }
    if (req.method === "GET" && url.pathname === "/api/hikvision/dashboard") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const devices = await dbPool.query(`
          SELECT d.*
          FROM hikvision_devices d
          ORDER BY d.device_type, d.location
        `);
        // Lookup nama dari hikvision_students (siswa) dan mst_teachers (guru/karyawan)
        const recentLogs = await dbPool.query(`
          SELECT l.*, d.ip_address, d.device_type,
            COALESCE(
              (SELECT payload->>'name' FROM mst_teachers WHERE payload->>'code' = l.employee_id OR id = l.employee_id OR payload->>'nip' = l.employee_id OR payload->>'id' = l.employee_id LIMIT 1),
              s.name,
              'Unknown'
            ) as student_name
          FROM hikvision_logs l 
          JOIN hikvision_devices d ON l.device_id = d.id 
          LEFT JOIN hikvision_students s ON l.employee_id = s.nis 
          ORDER BY l.timestamp DESC LIMIT 30
        `);
        send(req, res, 200, { ok: true, devices: devices.rows, recentLogs: recentLogs.rows });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
if (req.method === "POST" && url.pathname === "/api/hikvision/devices") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        const { ip_address, location, username, encrypted_password, class_id, device_type } = body;
        const { encrypted, iv } = encryptPassword(encrypted_password);
        await dbPool.query(
          "INSERT INTO hikvision_devices (ip_address, location, username, encrypted_password, iv_vector, class_id, device_type, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)",
          [ip_address, location, username, encrypted, iv, class_id || null, device_type || 'siswa']
        );
        send(req, res, 200, { ok: true, message: "Perangkat berhasil ditambahkan" });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "PUT" && url.pathname.startsWith("/api/hikvision/devices/")) {
      if (!requireAuthenticated(req, res)) return;
      try {
        const id = url.pathname.split("/").pop();
        const body = await readJsonBody(req);
        const { ip_address, location, username, encrypted_password, class_id, device_type } = body;
        
        // Fetch existing to check if password changed
        const existingRes = await dbPool.query("SELECT encrypted_password, iv_vector FROM hikvision_devices WHERE id = $1", [id]);
        let finalPass = encrypted_password;
        let finalIv = "";
        
        if (existingRes.rowCount > 0) {
          const existing = existingRes.rows[0];
          if (encrypted_password === existing.encrypted_password) {
            finalPass = existing.encrypted_password;
            finalIv = existing.iv_vector;
          } else {
            const { encrypted, iv } = encryptPassword(encrypted_password);
            finalPass = encrypted;
            finalIv = iv;
          }
        } else {
          const { encrypted, iv } = encryptPassword(encrypted_password);
          finalPass = encrypted;
          finalIv = iv;
        }

        await dbPool.query(
          "UPDATE hikvision_devices SET ip_address = $1, location = $2, username = $3, encrypted_password = $4, iv_vector = $5, class_id = $6, device_type = $7 WHERE id = $8",
          [ip_address, location, username, finalPass, finalIv, class_id || null, device_type || 'siswa', id]
        );
        send(req, res, 200, { ok: true, message: "Perangkat berhasil diupdate" });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "DELETE" && url.pathname.startsWith("/api/hikvision/devices/")) {
      if (!requireAuthenticated(req, res)) return;
      try {
        const id = url.pathname.split("/").pop();
        await dbPool.query("DELETE FROM hikvision_devices WHERE id = $1", [id]);
        send(req, res, 200, { ok: true, message: "Perangkat berhasil dihapus" });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/hikvision/report") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const startDate = url.searchParams.get("startDate");
        const endDate = url.searchParams.get("endDate");
        const deviceId = url.searchParams.get("deviceId");
        const reportType = url.searchParams.get("type") || 'siswa'; // siswa | guru | karyawan
        
        // Build name lookup depending on type
        const nameCoalesce = (reportType === 'siswa')
          ? `COALESCE(s.name, 'Unknown') as student_name, s.nis`
          : `COALESCE(
               (SELECT payload->>'name' FROM mst_teachers WHERE payload->>'code' = l.employee_id OR id = l.employee_id OR payload->>'nip' = l.employee_id OR payload->>'id' = l.employee_id LIMIT 1),
               s.name,
               'Unknown'
             ) as student_name, l.employee_id as nis`;

        let query = `
          SELECT l.id, l.timestamp, l.event_type, d.ip_address, d.location, d.device_type,
                 ${nameCoalesce}
          FROM hikvision_logs l
          JOIN hikvision_devices d ON l.device_id = d.id
          LEFT JOIN hikvision_students s ON l.employee_id = s.nis
          WHERE d.device_type = $1
        `;
        const params = [reportType];
        let paramCount = 2;
        
        if (startDate) {
          query += ` AND l.timestamp >= $${paramCount++}`;
          params.push(startDate + ' 00:00:00');
        }
        if (endDate) {
          query += ` AND l.timestamp <= $${paramCount++}`;
          params.push(endDate + ' 23:59:59');
        }
        if (deviceId && deviceId !== "all") {
          query += ` AND l.device_id = $${paramCount++}`;
          params.push(deviceId);
        }
        
        query += " ORDER BY l.timestamp DESC LIMIT 1000";
        
        const { rows } = await dbPool.query(query, params);
        send(req, res, 200, { ok: true, logs: rows });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/hikvision/config") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const conf = await getHikvisionConfig();
        send(req, res, 200, { ok: true, config: conf });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/config") {
      if (!requireAdmin(req, res)) return;
      try {
        const body = await readJsonBody(req);
        await dbPool.query(
          "INSERT INTO app_data (store_key, data) VALUES ('hikvision_attendance_config', $1) ON CONFLICT (store_key) DO UPDATE SET data = EXCLUDED.data, updated_at = CURRENT_TIMESTAMP",
          [JSON.stringify(body)]
        );
        send(req, res, 200, { ok: true, message: "Konfigurasi absensi berhasil disimpan." });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/manual-attendance") {
      const session = requireAuthenticated(req, res);
      if (!session) return;
      try {
        const body = await readJsonBody(req);
        const { user_type, user_id, date, status, reason } = body;
        if (!user_type || !user_id || !date || !status) {
           return send(req, res, 400, { ok: false, error: "Parameter tidak lengkap." });
        }
        await dbPool.query(
          "INSERT INTO attendance_manual (user_type, user_id, date, status, reason, created_by) VALUES ($1, $2, $3, $4, $5, $6)",
          [user_type, user_id, date, status, reason || '', session.role]
        );
        send(req, res, 200, { ok: true, message: "Absensi manual berhasil ditambahkan." });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/sync") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const syncResults = await pullHikvisionLogs();
        send(req, res, 200, { ok: true, syncResults: [syncResults] });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/sync-students") {
      if (!requireAuthenticated(req, res)) return;
      try {
        // Only sync from siswa devices
        const { rows: devices } = await dbPool.query("SELECT * FROM hikvision_devices WHERE device_type = 'siswa' OR device_type IS NULL");
        let totalSynced = 0;
        const syncResults = [];
        for (const device of devices) {
          try {
            const plainPassword = decryptPassword(device.encrypted_password, device.iv_vector);
            const api = new HikvisionAPI(device.ip_address, device.username, plainPassword);
            const users = await api.getUsers();
            if (!users || users.length === 0) {
              syncResults.push({ ip: device.ip_address, status: 'Success (0 pengguna)' });
              continue;
            }

            for (const u of users) {
              const nis = u.employeeNo;
              const name = u.name;
              let dbGrpId = null;
              if (u.groupId) {
                const grpRes = await dbPool.query(
                  "INSERT INTO hikvision_groups (device_id, group_id, group_name) VALUES ($1, $2, $3) ON CONFLICT (device_id, group_id) DO UPDATE SET group_name = EXCLUDED.group_name RETURNING id",
                  [device.id, u.groupId, `Group ${u.groupId}`]
                );
                dbGrpId = grpRes.rows[0].id;
              }
              await dbPool.query(
                "INSERT INTO hikvision_students (nis, name, device_group_id) VALUES ($1, $2, $3) ON CONFLICT (nis) DO UPDATE SET name = EXCLUDED.name, device_group_id = EXCLUDED.device_group_id RETURNING id",
                [nis, name, dbGrpId]
              );
              totalSynced++;
            }
            syncResults.push({ ip: device.ip_address, status: `Success (${users.length} pengguna)` });
          } catch (deviceError) {
            console.error(`Gagal sinkronisasi siswa untuk ${device.ip_address}:`, deviceError.message);
            syncResults.push({ ip: device.ip_address, status: `Error: ${deviceError.message}` });
          }
        }
        send(req, res, 200, { ok: true, message: `Berhasil sinkronisasi ${totalSynced} data pengguna dari alat siswa.`, syncResults });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/sync-staff") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const { rows: devices } = await dbPool.query("SELECT * FROM hikvision_devices WHERE device_type IN ('guru', 'karyawan')");
        let totalSynced = 0;
        const syncResults = [];
        for (const device of devices) {
          try {
            const plainPassword = decryptPassword(device.encrypted_password, device.iv_vector);
            const api = new HikvisionAPI(device.ip_address, device.username, plainPassword);
            const users = await api.getUsers();
            if (!users || users.length === 0) {
              syncResults.push({ ip: device.ip_address, type: device.device_type, status: 'Success (0 pengguna)' });
              continue;
            }

            for (const u of users) {
              const employeeId = u.employeeNo;
              const name = u.name;
              // Upsert ke hikvision_students dengan flag person_type
              await dbPool.query(
                "INSERT INTO hikvision_students (nis, name, class_name) VALUES ($1, $2, $3) ON CONFLICT (nis) DO UPDATE SET name = EXCLUDED.name",
                [employeeId, name, device.device_type]
              );
              totalSynced++;
            }
            syncResults.push({ ip: device.ip_address, type: device.device_type, status: `Success (${users.length} pengguna)` });
          } catch (deviceError) {
            console.error(`Gagal sinkronisasi staff untuk ${device.ip_address}:`, deviceError.message);
            syncResults.push({ ip: device.ip_address, type: device.device_type, status: `Error: ${deviceError.message}` });
          }
        }
        send(req, res, 200, { ok: true, message: `Berhasil sinkronisasi ${totalSynced} data guru/karyawan dari alat.`, syncResults });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/sync-attendance-guru") {
      if (!requireAuthenticated(req, res)) return;
      try {
        // 1. Ambil semua guru dari mst_teachers
        const teachersRes = await dbPool.query("SELECT id, payload FROM mst_teachers");
        // Buat map: kode mesin (employeeNo) → teacherCode
        // r.id = kode guru (primary key di DB = teacher code)
        const nipToCode = {};
        teachersRes.rows.forEach(r => {
          const t = r.payload;
          const code = t.code || r.id; // code dari payload, fallback ke row id
          if (r.id) nipToCode[String(r.id).trim().toLowerCase()] = code;
          if (t.code) nipToCode[String(t.code).trim().toLowerCase()] = code;
          if (t.nip) nipToCode[String(t.nip).trim().toLowerCase()] = code;
          if (t.id) nipToCode[String(t.id).trim().toLowerCase()] = code;
        });

        // 2. Ambil log dari mesin guru/karyawan
        const { rows: logs } = await dbPool.query(`
          SELECT l.employee_id, l.timestamp, l.event_type, d.ip_address, d.location
          FROM hikvision_logs l
          JOIN hikvision_devices d ON l.device_id = d.id
          WHERE d.device_type IN ('guru', 'karyawan')
          ORDER BY l.timestamp ASC
        `);

        if (logs.length === 0) {
          send(req, res, 200, { ok: true, message: "Tidak ada log guru untuk disinkronkan.", added: 0 });
          return;
        }

        // 3. Ambil app_data saat ini
        const mainRes = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'main_store'");
        const mainData = mainRes.rowCount > 0 ? JSON.parse(mainRes.rows[0].data) : {};
        const existingRecords = Array.isArray(mainData.attendanceRecords) ? mainData.attendanceRecords : [];

        // Buat Set dari ID yang sudah ada untuk dedup
        const existingIds = new Set(existingRecords.map(r => r.id));

        // 4. Konversi log hikvision → attendance records
        const conf = await getHikvisionConfig();
        let added = 0;
        const newRecords = [];

        logs.forEach(log => {
          const empId = String(log.employee_id || "").trim();
          const teacherCode = nipToCode[empId.toLowerCase()] || null;
          if (!teacherCode) return; // Skip jika guru tidak ditemukan di sistem

          const ts = new Date(log.timestamp);
          const year = ts.getFullYear();
          const month = String(ts.getMonth() + 1).padStart(2, "0");
          const day = String(ts.getDate()).padStart(2, "0");
          const date = `${year}-${month}-${day}`;
          const time = ts.toTimeString().substring(0, 5); // HH:MM
          
          let sessionName = "";
          let status = "";

          // Check window
          if (time >= conf.masuk_open && time <= conf.masuk_close) {
            sessionName = "Masuk Pagi";
            status = time > conf.masuk_late ? "Terlambat" : "Hadir";
          } else if (time >= conf.pulang_open && time <= conf.pulang_close) {
            sessionName = "Pulang Sore";
            status = "Hadir";
          } else {
            return; // Skip outside window scans
          }

          // Buat ID unik berdasarkan guru + tanggal + sesi
          const recordId = `hik-${teacherCode}-${date}-${sessionName}`;
          if (existingIds.has(recordId)) return;

          const record = {
            id: recordId,
            teacherCode,
            date,
            time,
            sessionName,
            status,
            mode: "hikvision",
            note: `Dari mesin Hikvision: ${log.location || log.ip_address}`,
          };

          newRecords.push(record);
          existingIds.add(recordId);
          added++;
        });

        // 5. Simpan kembali ke app_data
        if (added > 0) {
          mainData.attendanceRecords = [...existingRecords, ...newRecords];
          await dbPool.query(
            "INSERT INTO app_data (store_key, data) VALUES ('main_store', $1) ON CONFLICT (store_key) DO UPDATE SET data = EXCLUDED.data, updated_at = CURRENT_TIMESTAMP",
            [JSON.stringify(mainData)]
          );
        }

        send(req, res, 200, { ok: true, message: `Berhasil menambahkan ${added} data absensi guru dari mesin Hikvision.`, added, total_logs: logs.length });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/hikvision/config") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const conf = await getHikvisionConfig();
        send(req, res, 200, { ok: true, config: conf });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/config") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        // Ensure we accept both legacy flat configs and new nested configs
        const { masuk_open, masuk_late, masuk_close, pulang_open, pulang_close, notify_role, notify_custom_phone, siswa, guru, karyawan } = body;
        
        // Merge with existing config or default to prevent losing data if only one is updated
        const existingConf = await getHikvisionConfig();
        const newConf = { 
          ...existingConf,
          masuk_open: masuk_open !== undefined ? masuk_open : existingConf.masuk_open,
          masuk_late: masuk_late !== undefined ? masuk_late : existingConf.masuk_late,
          masuk_close: masuk_close !== undefined ? masuk_close : existingConf.masuk_close,
          pulang_open: pulang_open !== undefined ? pulang_open : existingConf.pulang_open,
          pulang_close: pulang_close !== undefined ? pulang_close : existingConf.pulang_close,
          notify_role: notify_role !== undefined ? notify_role : existingConf.notify_role,
          notify_custom_phone: notify_custom_phone !== undefined ? notify_custom_phone : existingConf.notify_custom_phone,
          siswa: siswa ? { ...(existingConf.siswa || {}), ...siswa } : existingConf.siswa,
          guru: guru ? { ...(existingConf.guru || {}), ...guru } : existingConf.guru,
          karyawan: karyawan ? { ...(existingConf.karyawan || {}), ...karyawan } : existingConf.karyawan
        };

        await dbPool.query(
          "INSERT INTO app_data (store_key, data) VALUES ('hikvision_attendance_config', $1) ON CONFLICT (store_key) DO UPDATE SET data = EXCLUDED.data, updated_at = CURRENT_TIMESTAMP",
          [JSON.stringify(newConf)]
        );
        send(req, res, 200, { ok: true, message: "Pengaturan absensi Hikvision berhasil disimpan.", config: newConf });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/manual-attendance") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        const { teacherCode, date, status, note } = body; // status: Izin, Sakit, Dinas Luar, Alpa, Hadir
        
        if (!teacherCode || !date || !status) {
          send(req, res, 400, { ok: false, error: "Data tidak lengkap" });
          return;
        }

        // 1. Ambil main_store
        const mainRes = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'main_store'");
        const mainData = mainRes.rowCount > 0 ? JSON.parse(mainRes.rows[0].data) : {};
        const existingRecords = Array.isArray(mainData.attendanceRecords) ? mainData.attendanceRecords : [];

        // Buat record ID unik: hik-manual-{teacherCode}-{date}
        const recordId = `hik-manual-${teacherCode}-${date}`;
        
        // Hapus record lama pada tanggal tersebut jika ada (agar tidak double/tumpang tindih)
        let filteredRecords = existingRecords.filter(r => r.id !== recordId && !(r.teacherCode === teacherCode && r.date === date));

        const record = {
          id: recordId,
          teacherCode,
          date,
          time: new Date().toTimeString().substring(0, 5),
          sessionName: "Manual",
          status,
          mode: "manual",
          note: note || `Diinput manual oleh admin`
        };

        filteredRecords.push(record);
        mainData.attendanceRecords = filteredRecords;

        // Simpan kembali
        await dbPool.query(
          "INSERT INTO app_data (store_key, data) VALUES ('main_store', $1) ON CONFLICT (store_key) DO UPDATE SET data = EXCLUDED.data, updated_at = CURRENT_TIMESTAMP",
          [JSON.stringify(mainData)]
        );

        // 2. WHATSAPP NOTIFIKASI
        // Ambil data guru yang bersangkutan
        const teacherRes = await dbPool.query("SELECT payload FROM mst_teachers WHERE id = $1", [teacherCode]);
        const teacher = teacherRes.rowCount > 0 ? teacherRes.rows[0].payload : null;
        
        if (teacher && (status === "Izin" || status === "Sakit")) {
          // Cari no WA tujuan
          let recipientPhone = String(teacher.notify_phone || "").replace(/\D/g, "");
          let recipientName = "Pengawas Absensi";

          if (!recipientPhone) {
            // Jika kosong, cari dari config global
            const conf = await getHikvisionConfig();
            const notifyRole = conf.notify_role || "none";
            
            if (notifyRole === "custom" && conf.notify_custom_phone) {
              recipientPhone = String(conf.notify_custom_phone).replace(/\D/g, "");
            } else if (notifyRole !== "none") {
              // Cari dari user list / teacher list
              let roleQuery = "";
              if (notifyRole === "kepsek") {
                roleQuery = "SELECT payload FROM mst_teachers WHERE payload->>'role' = 'kepsek' LIMIT 1";
              } else if (notifyRole === "waka_kurikulum") {
                roleQuery = "SELECT payload FROM mst_teachers WHERE payload->>'role' = 'waka' AND payload->>'division' = 'kurikulum' LIMIT 1";
              } else if (notifyRole === "waka_kesiswaan") {
                roleQuery = "SELECT payload FROM mst_teachers WHERE payload->>'role' = 'waka' AND payload->>'division' = 'kesiswaan' LIMIT 1";
              }

              if (roleQuery) {
                const roleRes = await dbPool.query(roleQuery);
                if (roleRes.rowCount > 0) {
                  const targetTeacher = roleRes.rows[0].payload;
                  recipientPhone = String(targetTeacher.phone || "").replace(/\D/g, "");
                  recipientName = targetTeacher.name || "Pihak Sekolah";
                }
              }
            }
          }

          // Format nomor penerima ke standar 62
          if (recipientPhone) {
            const phone = recipientPhone.startsWith("0") ? "62" + recipientPhone.slice(1) : recipientPhone;
            
            // Format isi pesan
            const message = `Pemberitahuan Kehadiran Guru:\n\nNama: ${teacher.name}\nKode Guru: ${teacherCode}\nStatus: ${status}\nTanggal: ${date}\nKeterangan: ${note || '-'}\n\nNotifikasi otomatis dari Sistem Absensi Sekolah.`;

            // Cari Fonnte API Key
            const keyRes = await dbPool.query("SELECT api_key FROM api_keys WHERE service_name = 'whatsapp_fonnte' AND is_active = true");
            if (keyRes.rowCount > 0) {
              const token = keyRes.rows[0].api_key;
              try {
                const fonnteRes = await fetch("https://api.fonnte.com/send", {
                  method: "POST",
                  headers: { "Authorization": token, "Content-Type": "application/json" },
                  body: JSON.stringify({ target: phone, message: message, countryCode: "62" })
                });
                const resData = await fonnteRes.json();
                
                // Simpan log WA
                const waStatus = (fonnteRes.ok && resData.status !== false) ? "sent" : "failed";
                await dbPool.query(
                  "INSERT INTO whatsapp_logs (phone, recipient_name, message, status, trigger_type, response_data) VALUES ($1,$2,$3,$4,$5,$6)",
                  [phone, recipientName, message, waStatus, "guru_izin_sakit", JSON.stringify(resData)]
                );
              } catch (e) {
                console.error("Gagal mengirim WA notifikasi guru:", e.message);
              }
            }
          }
        }

        send(req, res, 200, { ok: true, message: `Berhasil mencatat status ${status} guru ${teacherCode}.` });
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/sync-teachers-to-data") {
      if (!requireAuthenticated(req, res)) return;
      try {
        // Ambil pengguna mesin guru yang belum ada di mst_teachers (berdasarkan NIP)
        const staffRes = await dbPool.query(`
          SELECT s.nis as employee_id, s.name as device_name
          FROM hikvision_students s
          WHERE s.class_name IN ('guru', 'karyawan')
        `);
        const staffList = staffRes.rows;
        if (staffList.length === 0) {
          send(req, res, 200, { ok: true, message: "Tidak ada data guru/karyawan dari mesin untuk disinkronkan.", updated: 0, added: 0 });
          return;
        }

        // Baca mst_teachers payload - buat map kode/nip → teacher data
        const teachersRes = await dbPool.query("SELECT id, payload FROM mst_teachers");
        const teacherRows = teachersRes.rows;
        const codeMap = {}; // key: kode mesin (bisa kode guru / nip / id) → teacher
        teacherRows.forEach(r => {
          const p = r.payload;
          // r.id adalah kode guru (primary key, hasil saveToTable dengan idKey='code')
          if (r.id) codeMap[String(r.id).trim().toLowerCase()] = { id: r.id, payload: p };
          // p.code adalah kode guru dari payload
          if (p.code) codeMap[String(p.code).trim().toLowerCase()] = { id: r.id, payload: p };
          // Fallback ke nip dan id jika ada
          if (p.nip) codeMap[String(p.nip).trim().toLowerCase()] = { id: r.id, payload: p };
          if (p.id) codeMap[String(p.id).trim().toLowerCase()] = { id: r.id, payload: p };
        });

        let updated = 0;
        let skipped = 0;
        const unmatched = [];

        for (const staff of staffList) {
          const empId = String(staff.employee_id || "").trim();
          const empIdLower = empId.toLowerCase();
          const found = codeMap[empIdLower];
          if (found) {
            // Update nama di payload jika nama masih kosong / sama dengan ID
            if (!found.payload.name || found.payload.name === empId) {
              found.payload.name = staff.device_name;
              await dbPool.query(
                "UPDATE mst_teachers SET payload = $1 WHERE id = $2",
                [JSON.stringify(found.payload), found.id]
              );
              updated++;
            } else {
              updated++; // sudah cocok, tidak perlu update nama
            }
          } else {
            // Jangan otomatis tambah guru baru, biarkan admin yang mencocokkan secara manual
            unmatched.push(empId);
            skipped++;
          }
        }

        send(req, res, 200, {
          ok: true,
          message: `Sinkronisasi selesai. ${updated} ID mesin cocok dengan guru di sistem, ${skipped} belum cocok.`,
          updated,
          skipped,
          unmatched // daftar ID mesin yang belum cocok, untuk referensi admin
        });
      } catch (err) {
        sendDatabaseError(req, res, err);
      }
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/hikvision/students") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const personType = url.searchParams.get("type") || "siswa"; // siswa | guru | karyawan | staff(guru+karyawan)
        
        let rows;
        if (personType === "siswa") {
          // Siswa: ambil dari hikvision_students yang NOT IN (guru, karyawan)
          const result = await dbPool.query(`
            SELECT s.*, g.group_name, d.ip_address as device_ip,
              'siswa' as person_type
            FROM hikvision_students s
            LEFT JOIN hikvision_groups g ON s.device_group_id = g.id
            LEFT JOIN hikvision_devices d ON g.device_id = d.id
            WHERE s.class_name NOT IN ('guru', 'karyawan') OR s.class_name IS NULL
            ORDER BY s.class_name NULLS LAST, s.name ASC
          `);
          rows = result.rows;
        } else {
          // Guru / karyawan: ambil dari hikvision_students yang class_name = tipe tsb
          // Dan enrichment nama dari mst_teachers
          const typeFilter = personType === "staff" ? ["guru", "karyawan"] : [personType];
          const placeholders = typeFilter.map((_, i) => `$${i + 1}`).join(", ");
          const result = await dbPool.query(`
            SELECT s.nis, s.name as device_name, s.class_name as person_type,
              COALESCE(
                (SELECT payload->>'name' FROM mst_teachers WHERE payload->>'code' = s.nis OR id = s.nis OR payload->>'nip' = s.nis OR payload->>'id' = s.nis LIMIT 1),
                s.name
              ) as name,
              (SELECT payload->>'mapel' FROM mst_teachers WHERE payload->>'code' = s.nis OR id = s.nis OR payload->>'nip' = s.nis OR payload->>'id' = s.nis LIMIT 1) as mapel,
              (SELECT payload->>'nip' FROM mst_teachers WHERE payload->>'code' = s.nis OR id = s.nis OR payload->>'nip' = s.nis OR payload->>'id' = s.nis LIMIT 1) as nip,
              (SELECT payload->>'code' FROM mst_teachers WHERE payload->>'code' = s.nis OR id = s.nis OR payload->>'nip' = s.nis OR payload->>'id' = s.nis LIMIT 1) as code,
              EXISTS(
                SELECT 1 FROM mst_teachers WHERE payload->>'code' = s.nis OR id = s.nis OR payload->>'nip' = s.nis OR payload->>'id' = s.nis
              ) as is_connected
            FROM hikvision_students s
            WHERE s.class_name IN (${placeholders})
            ORDER BY s.class_name, s.name ASC
          `, typeFilter);
          rows = result.rows;
        }
        send(req, res, 200, { ok: true, data: rows });
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }
    if (req.method === "PUT" && url.pathname === "/api/hikvision/students/bulk") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        const updates = body.updates || [];
        
        await dbPool.query('BEGIN');
        for (const update of updates) {
          await dbPool.query(
            "UPDATE hikvision_students SET class_name = $1 WHERE nis = $2",
            [update.class_name, update.nis]
          );
        }
        await dbPool.query('COMMIT');
        
        send(req, res, 200, { ok: true, message: "Berhasil memperbarui pemetaan secara massal." });
      } catch (err) { 
        await dbPool.query('ROLLBACK');
        sendDatabaseError(req, res, err); 
      }
      return;
    }
    if (req.method === "PUT" && url.pathname.startsWith("/api/hikvision/students/")) {
      if (!requireAuthenticated(req, res)) return;
      try {
        const nis = url.pathname.split("/").pop();
        const body = await readJsonBody(req);
        const className = body.class_name || null;
        await dbPool.query(
          "UPDATE hikvision_students SET class_name = $1 WHERE nis = $2",
          [className, nis]
        );
        send(req, res, 200, { ok: true, message: "Berhasil memperbarui pemetaan kelas." });
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/hikvision/report/matrix") {
      if (!requireAuthenticated(req, res)) return;
      try {
        const body = await readJsonBody(req);
        const month = parseInt(body.month) || new Date().getMonth() + 1;
        const year = parseInt(body.year) || new Date().getFullYear();
        const className = body.class_name || 'all';
        const reportType = body.type || 'siswa'; // siswa | guru | karyawan | staff

        let studentsQueryStr = "";
        let queryParams = [month, year];
        let classFilter = "";

        if (reportType === 'siswa') {
          studentsQueryStr = `
            SELECT nis, name, class_name 
            FROM hikvision_students s
            WHERE 1=1
          `;
          if (className === 'all') {
            studentsQueryStr += " AND s.class_name NOT IN ('guru', 'karyawan')";
          } else {
            studentsQueryStr += " AND s.class_name = $1";
            classFilter = "AND s.class_name = $3";
            queryParams.push(className);
          }
        } else {
          // Guru / Karyawan / Staff
          if (reportType === 'guru') {
            studentsQueryStr = `
              SELECT 
                COALESCE(payload->>'code', payload->>'nip', id) as nis, 
                'guru' as class_name, 
                COALESCE(payload->>'name', payload->>'nama', id) as name 
              FROM mst_teachers
            `;
          } else if (reportType === 'karyawan') {
            studentsQueryStr = `
              SELECT 
                COALESCE(payload->>'staff_code', id) as nis, 
                'karyawan' as class_name, 
                COALESCE(payload->>'name', payload->>'nama', id) as name 
              FROM mst_staffs
            `;
          } else {
            studentsQueryStr = `
              SELECT COALESCE(payload->>'code', payload->>'nip', id) as nis, 'guru' as class_name, COALESCE(payload->>'name', payload->>'nama', id) as name FROM mst_teachers
              UNION ALL
              SELECT COALESCE(payload->>'staff_code', id) as nis, 'karyawan' as class_name, COALESCE(payload->>'name', payload->>'nama', id) as name FROM mst_staffs
            `;
          }
        }

        const studentsQuery = await dbPool.query(studentsQueryStr, (reportType === 'siswa' && className !== 'all') ? [className] : []);
        
        let logsQueryStr = "";
        if (reportType === 'siswa') {
          logsQueryStr = `
            SELECT l.employee_id, l.timestamp, l.event_type, s.name, s.class_name
            FROM hikvision_logs l
            JOIN hikvision_students s ON l.employee_id = s.nis
            WHERE EXTRACT(MONTH FROM l.timestamp) = $1 AND EXTRACT(YEAR FROM l.timestamp) = $2
            ${classFilter}
            ORDER BY l.timestamp ASC
          `;
        } else {
          const types = reportType === 'staff' ? ['guru', 'karyawan'] : [reportType];
          logsQueryStr = `
            SELECT l.employee_id, l.timestamp, l.event_type, 
              COALESCE(
                (SELECT COALESCE(payload->>'name', payload->>'nama') FROM mst_teachers WHERE payload->>'code' = l.employee_id OR id = l.employee_id OR payload->>'nip' = l.employee_id LIMIT 1),
                (SELECT COALESCE(payload->>'name', payload->>'nama') FROM mst_staffs WHERE payload->>'staff_code' = l.employee_id OR id = l.employee_id LIMIT 1),
                'Unknown'
              ) as name,
              l.person_type as class_name
            FROM hikvision_logs l
            WHERE EXTRACT(MONTH FROM l.timestamp) = $1 AND EXTRACT(YEAR FROM l.timestamp) = $2
            AND l.person_type IN (${types.map(t => `'${t}'`).join(',')})
            ORDER BY l.timestamp ASC
          `;
        }

        const logsQuery = await dbPool.query(logsQueryStr, (reportType === 'siswa' && className !== 'all') ? [month, year, className] : [month, year]);

        // Process matrix in memory
        const daysInMonth = new Date(year, month, 0).getDate();
        const matrix = {};
        
        // Initialize with all students/teachers
        studentsQuery.rows.forEach(s => {
            matrix[s.nis] = {
                nis: s.nis,
                name: s.name,
                class_name: s.class_name,
                total_hadir: 0,
                total_terlambat: 0,
                total_izin: 0,
                total_sakit: 0,
                total_alpa: 0,
                days: {}
            };
        });

        const conf = await getHikvisionConfig();
        const masukOpen = conf.masuk_open + ":00";
        const masukLate = conf.masuk_late + ":00";
        const masukClose = conf.masuk_close + ":00";
        const pulangOpen = conf.pulang_open + ":00";
        const pulangClose = conf.pulang_close + ":00";
        
        logsQuery.rows.forEach(log => {
            const nis = log.employee_id;
            if (!matrix[nis]) {
                 matrix[nis] = { nis, name: log.name, class_name: log.class_name, total_hadir: 0, total_terlambat: 0, total_izin: 0, total_sakit: 0, total_alpa: 0, days: {} };
            }
            
            const dateObj = new Date(log.timestamp);
            const day = dateObj.getDate();
            const timeStr = dateObj.toTimeString().substring(0, 8); // HH:MM:SS
            
            if (!matrix[nis].days[day]) {
                 matrix[nis].days[day] = { in: null, out: null, isLate: false };
            }
            
            if (timeStr >= masukOpen && timeStr <= masukClose) {
                if (!matrix[nis].days[day].in || timeStr < matrix[nis].days[day].in) {
                    matrix[nis].days[day].in = timeStr;
                    matrix[nis].days[day].isLate = timeStr > masukLate;
                }
            } else if (timeStr >= pulangOpen && timeStr <= pulangClose) {
                if (!matrix[nis].days[day].out || timeStr > matrix[nis].days[day].out) {
                    matrix[nis].days[day].out = timeStr;
                }
            } else {
                if (!matrix[nis].days[day].in) {
                    matrix[nis].days[day].in = timeStr;
                    matrix[nis].days[day].isLate = timeStr > masukLate;
                } else {
                    if (!matrix[nis].days[day].out || timeStr > matrix[nis].days[day].out) {
                        matrix[nis].days[day].out = timeStr;
                    }
                }
            }
        });

        // Ambil manual attendance records (e.g. Izin, Sakit, Alpa)
        const mainRes = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'main_store'");
        const mainData = mainRes.rowCount > 0 ? JSON.parse(mainRes.rows[0].data) : {};
        const attendanceRecords = Array.isArray(mainData.attendanceRecords) ? mainData.attendanceRecords : [];

        // Build teacher code/nip mapping
        const teachersRes = await dbPool.query("SELECT id, payload FROM mst_teachers");
        const codeToNis = {};
        teachersRes.rows.forEach(r => {
          const t = r.payload;
          const code = (t.code || r.id).toLowerCase();
          const matched = studentsQuery.rows.find(s => 
            s.nis.toLowerCase() === code ||
            s.nis.toLowerCase() === String(t.nip || '').trim().toLowerCase() ||
            s.nis.toLowerCase() === String(t.id || '').trim().toLowerCase()
          );
          if (matched) {
            codeToNis[code] = matched.nis;
            if (t.nip) codeToNis[String(t.nip).trim().toLowerCase()] = matched.nis;
          }
        });

        // Overlay manual attendance records
        attendanceRecords.forEach(rec => {
          const recDate = new Date(rec.date);
          if (isNaN(recDate.getTime())) return;
          const recMonth = recDate.getMonth() + 1;
          const recYear = recDate.getFullYear();
          if (recMonth !== month || recYear !== year) return;

          const matchedNis = codeToNis[rec.teacherCode.toLowerCase()] || rec.teacherCode;
          if (matrix[matchedNis]) {
            const day = recDate.getDate();
            const status = rec.status;
            
            if (["Izin", "Sakit", "Dinas Luar", "Alpa"].includes(status)) {
              matrix[matchedNis].days[day] = {
                in: status,
                out: status,
                isLate: false,
                isManual: true,
                status: status,
                note: rec.note
              };
            } else if (["Hadir", "Terlambat"].includes(status)) {
              matrix[matchedNis].days[day] = {
                in: rec.time || "07:00",
                out: rec.time || "07:00",
                isLate: status === "Terlambat",
                isManual: true,
                status: status,
                note: rec.note
              };
            }
          }
        });

        // Recount lates and presence properly
        Object.values(matrix).forEach(item => {
            let totalHadir = 0;
            let totalTerlambat = 0;
            let totalIzin = 0;
            let totalSakit = 0;
            let totalAlpa = 0;

            Object.values(item.days).forEach(dayData => {
                if (dayData.status) {
                  if (dayData.status === "Izin") totalIzin++;
                  else if (dayData.status === "Sakit") totalSakit++;
                  else if (dayData.status === "Alpa") totalAlpa++;
                  else if (dayData.status === "Hadir" || dayData.status === "Terlambat") {
                    totalHadir++;
                    if (dayData.status === "Terlambat") totalTerlambat++;
                  }
                } else if (dayData.in || dayData.out) {
                    totalHadir++;
                    if (dayData.isLate) {
                        totalTerlambat++;
                    }
                }
            });
            item.total_hadir = totalHadir;
            item.total_terlambat = totalTerlambat;
            item.total_izin = totalIzin;
            item.total_sakit = totalSakit;
            item.total_alpa = totalAlpa;
        });

        send(req, res, 200, { 
            ok: true, 
            month, 
            year, 
            daysInMonth,
            data: Object.values(matrix).sort((a,b) => a.name.localeCompare(b.name))
        });
      } catch (err) { sendDatabaseError(req, res, err); }
      return;
    }

  return false;
}
