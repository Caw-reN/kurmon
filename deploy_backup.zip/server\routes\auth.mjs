export async function handleAuthRoutes(req, res, url, ctx) {
  const {
    dbPool,
    send,
    sendDatabaseError,
    requireAuthenticated,
    readJsonBody,
    readMainPayload,
    createDatabaseUnavailableError,
    verifyPassword,
    createSession,
    ensureDatabaseReadable,
    normalizeServerRole,
    dbStatus
  } = ctx;

  if (req.method === "GET" && url.pathname === "/api/auth/ping") {
    send(req, res, 200, { ok: true, database: dbStatus });
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/auth/sync") {
    const session = requireAuthenticated(req, res);
    if (!session) return true;
    if (!["admin", "superadmin"].includes(normalizeServerRole(session.role))) {
      send(req, res, 403, { ok: false, error: "Hanya admin yang dapat melakukan sinkronisasi akun." });
      return true;
    }
    try {
      if (!dbPool) throw createDatabaseUnavailableError();
      const body = await readJsonBody(req);
      const nextAdmin = body.adminUser;
      const nextTeachers = Array.isArray(body.teachers) ? body.teachers : null;

      const existingPayload = await readMainPayload();
      if (!existingPayload) throw new Error("Payload not found in database.");

      const mergedPayload = { ...existingPayload };
      if (nextAdmin) {
        mergedPayload.adminUser = {
          ...existingPayload.adminUser,
          ...nextAdmin,
          password: nextAdmin.password || existingPayload.adminUser?.password,
        };
      }
      if (nextTeachers) {
        mergedPayload.teachers = nextTeachers.map((t) => {
          const old = (existingPayload.teachers || []).find((ot) => ot.code === t.code);
          return old && old.password && !t.password ? { ...t, password: old.password } : t;
        });
      }

      const dataString = JSON.stringify(mergedPayload);
      await dbPool.query(
        `INSERT INTO app_data (store_key, data) VALUES ('main_store', $1)
         ON CONFLICT (store_key) DO UPDATE SET data = EXCLUDED.data, updated_at = CURRENT_TIMESTAMP`,
        [dataString]
      );
      send(req, res, 200, { ok: true });
    } catch (err) {
      console.error("Sync error:", err);
      sendDatabaseError(req, res, err);
    }
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/auth/login") {
    const body = await readJsonBody(req);
    const username = String(body.username || "").trim().toLowerCase();
    const password = String(body.password || "");
    console.log(`Login attempt: user='${username}', passLength=${password.length}`);
    
    try {
      const payload = await readMainPayload();
      try {
        const dbTeachers = await dbPool.query('SELECT payload FROM mst_teachers');
        if (dbTeachers.rows.length > 0) payload.teachers = dbTeachers.rows.map(r => r.payload);
      } catch (e) {}
      try {
        const dbClasses = await dbPool.query('SELECT payload FROM mst_classes');
        if (dbClasses.rows.length > 0) payload.classes = dbClasses.rows.map(r => r.payload);
      } catch (e) {}
      if (!payload) throw new Error("Main payload empty");
      
      // Admin login
      if (username && payload.adminUser?.username?.trim().toLowerCase() === username) {
        const isValid = await verifyPassword(password, payload.adminUser.password);
        if (isValid) {
          if (!await ensureDatabaseReadable(req, res)) return true;
          try { await dbPool.query("INSERT INTO login_logs (username, role, ip) VALUES ($1, $2, $3)", [username, 'admin', req.socket?.remoteAddress || '']); } catch {}
          try {
            await dbPool.query(
              "INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1, $2, $3, $4, $5, $6)",
              [username, payload.adminUser.name || "Admin", "admin", "LOGIN", "session", "Admin berhasil masuk ke sistem"]
            );
          } catch (err) { console.error(err); }
          send(req, res, 200, { ok: true, user: { role: "admin", name: payload.adminUser.name, authToken: createSession("admin", { id: payload.adminUser.username || "admin", username: payload.adminUser.username || "admin" }) } });
          return true;
        }
      }

      // Teacher login
      const teacher = (payload.teachers || []).find((item) => String(item.code || "").trim().toLowerCase() === username);
      
      let isTeacherValid = false;
      if (teacher) {
        if (teacher.password) {
          isTeacherValid = await verifyPassword(password, teacher.password);
        } else {
          isTeacherValid = (password === String(teacher.code).trim() || password === "123456");
        }
      }

      if (teacher && isTeacherValid) {
        if (!await ensureDatabaseReadable(req, res)) return true;
        let role = normalizeServerRole(teacher.role);
        let walasClass = null;
        let isWalas = false;
        try {
          const homeroomClass = (payload.classes || []).find(c => String(c.homeroom || "").trim() === String(teacher.code).trim());
          if (homeroomClass) {
              isWalas = true;
              walasClass = homeroomClass.name;
          }
        } catch (e) {}
        try { await dbPool.query("INSERT INTO login_logs (username, role, ip) VALUES ($1, $2, $3)", [teacher.code, role, req.socket?.remoteAddress || '']); } catch {}
        try {
          await dbPool.query(
            "INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1, $2, $3, $4, $5, $6)",
            [teacher.code, teacher.name || "Guru", role, "LOGIN", "session", `Guru/Staff (${teacher.name}) berhasil masuk ke sistem`]
          );
        } catch (err) { console.error(err); }
        send(req, res, 200, { ok: true, user: { role, code: teacher.code, name: teacher.name, division: teacher.division || "", isWalas, walasClass, authToken: createSession(role, { id: teacher.code, username: teacher.code }) } });
        return true;
      }
    } catch (err) {
      console.warn("Error reading main payload for login", err);
    }


    // Check users table (siswa & staff with DB accounts)
    if (dbPool) {
      try {
        const { rows: userRows } = await dbPool.query(
          "SELECT id, username, password, name, role FROM users WHERE username = $1", [username]
        );
        if (userRows.length > 0) {
          const dbUser = userRows[0];
          const isValid = await verifyPassword(password, dbUser.password);
          if (isValid) {
            const role = normalizeServerRole(dbUser.role);
            const token = createSession(role, { id: dbUser.id, username: dbUser.username });
            try { await dbPool.query("INSERT INTO login_logs (username, role, ip) VALUES ($1, $2, $3)", [dbUser.username, role, req.socket?.remoteAddress || '']); } catch {}
            try {
              await dbPool.query(
                "INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1, $2, $3, $4, $5, $6)",
                [dbUser.username, dbUser.name || "Siswa", role, "LOGIN", "session", `Siswa/User (${dbUser.name}) berhasil masuk ke sistem`]
              );
            } catch (err) { console.error(err); }
            send(req, res, 200, { ok: true, user: { role, id: dbUser.id, name: dbUser.name, username: dbUser.username, authToken: token } });
            return true;
          }
        }
      } catch (dbErr) {
        console.warn("Users table lookup failed:", dbErr.message);
      }
    }
    
    // Check students array for PKL login
    if (dbPool) {
      try {
        const { rows: storeRows } = await dbPool.query(`SELECT (data::json)->'students' as students FROM app_data WHERE store_key = 'main_store'`);
        let students = (storeRows.length > 0 && Array.isArray(storeRows[0].students)) ? storeRows[0].students : [];
        try {
          const dbStudents = await dbPool.query('SELECT payload FROM mst_students');
          if (dbStudents.rows.length > 0) students = dbStudents.rows.map(r => r.payload);
        } catch(e) {}
           const student = students.find(s => String(s.nis).trim().toLowerCase() === username);
           if (student) {
               const { rows: pklRows } = await dbPool.query("SELECT data FROM app_data WHERE store_key = 'pkl_settings'");
               const pklSettings = pklRows.length > 0 ? JSON.parse(pklRows[0].data) : { eligibleClass: "XII" };
               const eligibleClass = pklSettings.eligibleClass || "XII";

              if (student.class_name && student.class_name.toUpperCase().startsWith(eligibleClass.toUpperCase())) {
                 if (password === String(student.nis).trim() || password === "123456") {
                    const token = createSession("siswa", { id: student.nis, username: student.nis });
                    send(req, res, 200, { ok: true, user: { role: "siswa", id: student.nis, name: student.name, username: student.nis, class_name: student.class_name, authToken: token } });
                    return true;
                 }
              } else {
                 send(req, res, 401, { ok: false, error: `Akses ditolak. Login saat ini hanya untuk siswa kelas ${eligibleClass} (PKL).` });
                 return true;
              }
           }
      } catch (dbErr) {
        console.warn("Failed to check student login via app_data:", dbErr.message);
      }
    }

    send(req, res, 401, { ok: false, error: "Username atau password salah." });
    return true;
  }

  return false;
}
