export async function handleKedisiplinanRoutes(req, res, url, ctx) {
  const { dbPool, send, sendDatabaseError, requireAuthenticated, getSession, readJsonBody, readMainPayload, isMonitoringAdmin, isAdminRole } = ctx;
  
    if (url.pathname.startsWith("/api/kedisiplinan/")) {
      if (!requireAuthenticated(req, res)) return;
      
      try {
        if (req.method === "GET" && url.pathname === "/api/kedisiplinan/master") {
          const { rows } = await dbPool.query("SELECT * FROM kedisiplinan_master_poin ORDER BY nama_tindakan ASC");
          send(req, res, 200, { ok: true, data: rows });
          return;
        }
        if (req.method === "POST" && url.pathname === "/api/kedisiplinan/master") {
          const body = await readJsonBody(req);
          if (body.action === 'delete') {
             await dbPool.query("DELETE FROM kedisiplinan_master_poin WHERE id = $1", [body.id]);
          } else if (body.id) {
             await dbPool.query("UPDATE kedisiplinan_master_poin SET nama_tindakan = $1, jenis = $2, nilai_poin = $3 WHERE id = $4", [body.nama_tindakan, body.jenis, body.nilai_poin, body.id]);
          } else {
             await dbPool.query("INSERT INTO kedisiplinan_master_poin (nama_tindakan, jenis, nilai_poin) VALUES ($1, $2, $3)", [body.nama_tindakan, body.jenis, body.nilai_poin]);
          }
          send(req, res, 200, { ok: true });
          return;
        }

        if (req.method === "GET" && url.pathname === "/api/kedisiplinan/jadwal") {
          const { rows } = await dbPool.query("SELECT * FROM kedisiplinan_jadwal_mingguan ORDER BY id ASC");
          send(req, res, 200, { ok: true, data: rows });
          return;
        }
        if (req.method === "POST" && url.pathname === "/api/kedisiplinan/jadwal") {
          const body = await readJsonBody(req);
          if (body.action === 'delete') {
             await dbPool.query("DELETE FROM kedisiplinan_jadwal_mingguan WHERE id = $1", [body.id]);
          } else if (body.id) {
             await dbPool.query("UPDATE kedisiplinan_jadwal_mingguan SET hari = $1, kampus = $2, guru_ids = $3 WHERE id = $4", [body.hari, body.kampus, JSON.stringify(body.guru_ids || []), body.id]);
          } else {
             await dbPool.query("INSERT INTO kedisiplinan_jadwal_mingguan (hari, kampus, guru_ids) VALUES ($1, $2, $3)", [body.hari, body.kampus, JSON.stringify(body.guru_ids || [])]);
          }
          send(req, res, 200, { ok: true });
          return;
        }

        if (req.method === "GET" && url.pathname === "/api/kedisiplinan/riwayat") {
          const { rows } = await dbPool.query("SELECT * FROM kedisiplinan_riwayat_poin ORDER BY tanggal_kejadian DESC");
          send(req, res, 200, { ok: true, data: rows });
          return;
        }
        if (req.method === "POST" && url.pathname === "/api/kedisiplinan/riwayat") {
          const body = await readJsonBody(req);
          if (body.action === 'delete') {
             await dbPool.query("DELETE FROM kedisiplinan_riwayat_poin WHERE id = $1", [body.id]);
          } else {
             const session = getSession(req);
             await dbPool.query("INSERT INTO kedisiplinan_riwayat_poin (siswa_nis, tindakan_id, tindakan_nama, poin, jenis, pelapor_id, pelapor_nama, catatan) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)", [body.siswa_nis, body.tindakan_id, body.tindakan_nama, body.poin, body.jenis, session?.id, session?.name || 'Sistem', body.catatan]);
          }
          send(req, res, 200, { ok: true });
          return;
        }
        
        if (req.method === "GET" && url.pathname === "/api/kedisiplinan/konseling") {
          const { rows } = await dbPool.query("SELECT * FROM kedisiplinan_buku_konseling ORDER BY tanggal_konseling DESC");
          send(req, res, 200, { ok: true, data: rows });
          return;
        }
        if (req.method === "POST" && url.pathname === "/api/kedisiplinan/konseling") {
          const body = await readJsonBody(req);
          if (body.action === 'delete') {
             await dbPool.query("DELETE FROM kedisiplinan_buku_konseling WHERE id = $1", [body.id]);
          } else {
             const session = getSession(req);
             await dbPool.query("INSERT INTO kedisiplinan_buku_konseling (siswa_nis, guru_bk_id, guru_bk_nama, jenis_kasus, tindak_lanjut, catatan_konseling, status) VALUES ($1, $2, $3, $4, $5, $6, $7)", [body.siswa_nis, session?.id, session?.name || 'BPBK', body.jenis_kasus, body.tindak_lanjut, body.catatan_konseling, body.status || 'Selesai']);
          }
          send(req, res, 200, { ok: true });
          return;
        }

        if (req.method === "GET" && url.pathname === "/api/kedisiplinan/absensi") {
          const { rows } = await dbPool.query("SELECT * FROM kedisiplinan_absensi ORDER BY tanggal DESC, id DESC");
          send(req, res, 200, { ok: true, data: rows });
          return;
        }
        if (req.method === "POST" && url.pathname === "/api/kedisiplinan/absensi") {
          const body = await readJsonBody(req);
          if (body.action === 'delete') {
             await dbPool.query("DELETE FROM kedisiplinan_absensi WHERE id = $1", [body.id]);
          } else if (body.action === 'update') {
             await dbPool.query("UPDATE kedisiplinan_absensi SET status = $1, keterangan = $2, gdrive_url = COALESCE($3, gdrive_url) WHERE id = $4", [body.status, body.keterangan, body.gdrive_url, body.id]);
          } else {
             const session = getSession(req);
             await dbPool.query("INSERT INTO kedisiplinan_absensi (siswa_nis, tanggal, status, keterangan, pelapor_id, pelapor_nama) VALUES ($1, $2, $3, $4, $5, $6)", [body.siswa_nis, body.tanggal, body.status, body.keterangan, session?.id, session?.name || 'Sistem']);
          }
          send(req, res, 200, { ok: true });
          return;
        }

      } catch (err) {
         console.error("Kedisiplinan API Error:", err);
         sendDatabaseError(req, res, err);
      }
      return;
    }

  return false;
}
