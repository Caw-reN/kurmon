export async function handleDataRoutes(req, res, url, ctx) {
  const {
    dbPool,
    send,
    sendDatabaseError,
    requireAuthenticated,
    getSession,
    readJsonBody,
    readMainPayload,
    createDatabaseUnavailableError,
    syncAllUsersToModules,
    toPublicPayload,
    sanitizePayload
  } = ctx;

  if (req.method === "GET" && url.pathname === "/api/data/public") {
    try {
      const payload = await readMainPayload();
      
      // Merge with relational tables
      try {
        const [majors, classes, rooms, teachers, subjects, students] = await Promise.all([
          dbPool.query('SELECT payload FROM mst_majors'),
          dbPool.query('SELECT payload FROM mst_classes'),
          dbPool.query('SELECT payload FROM mst_rooms'),
          dbPool.query('SELECT payload FROM mst_teachers'),
          dbPool.query('SELECT payload FROM mst_subjects'),
          dbPool.query('SELECT payload FROM mst_students')
        ]);
        if (majors.rows.length > 0) payload.majors = majors.rows.map(r => r.payload);
        if (classes.rows.length > 0) payload.classes = classes.rows.map(r => r.payload);
        if (rooms.rows.length > 0) payload.rooms = rooms.rows.map(r => r.payload);
        if (teachers.rows.length > 0) payload.teachers = teachers.rows.map(r => r.payload);
        if (subjects.rows.length > 0) payload.subjects = subjects.rows.map(r => r.payload);
        if (students.rows.length > 0) payload.students = students.rows.map(r => r.payload);
      } catch (e) {
        console.warn("Failed to merge relational tables on load", e);
      }

      console.log("Sending payload for /api/data/public");
      send(req, res, 200, { ok: true, payload: payload ? toPublicPayload(payload) : null });
    } catch (err) {
      console.error("Load Data Error:", err);
      sendDatabaseError(req, res, err);
    }
    return true;
  }

  if (req.method === "GET" && url.pathname === "/api/data/load") {
    if (!requireAuthenticated(req, res)) return true;
    try {
      const payload = await readMainPayload();

      // Merge with relational tables
      try {
        const [majors, classes, rooms, teachers, subjects, students, staffs] = await Promise.all([
          dbPool.query('SELECT payload FROM mst_majors'),
          dbPool.query('SELECT payload FROM mst_classes'),
          dbPool.query('SELECT payload FROM mst_rooms'),
          dbPool.query('SELECT payload FROM mst_teachers'),
          dbPool.query('SELECT payload FROM mst_subjects'),
          dbPool.query('SELECT payload FROM mst_students'),
          dbPool.query('SELECT payload FROM mst_staffs')
        ]);
        if (majors.rows.length > 0) payload.majors = majors.rows.map(r => r.payload);
        if (classes.rows.length > 0) payload.classes = classes.rows.map(r => r.payload);
        if (rooms.rows.length > 0) payload.rooms = rooms.rows.map(r => r.payload);
        if (teachers.rows.length > 0) payload.teachers = teachers.rows.map(r => r.payload);
        if (subjects.rows.length > 0) payload.subjects = subjects.rows.map(r => r.payload);
        if (students.rows.length > 0) payload.students = students.rows.map(r => r.payload);
        if (staffs.rows.length > 0) payload.staffs = staffs.rows.map(r => r.payload);
      } catch (e) {
        console.warn("Failed to merge relational tables on load", e);
      }

      send(req, res, 200, { ok: true, payload: payload ? sanitizePayload(payload) : null });
    } catch (err) {
      console.error("Load Data Error:", err);
      sendDatabaseError(req, res, err);
    }
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/data/save") {
    if (!requireAuthenticated(req, res)) return true;
    try {
      if (!dbPool) throw createDatabaseUnavailableError();
      const body = await readJsonBody(req);
      const payload = body.payload || {};
      
      // Preserve passwords that might be missing from frontend state due to sanitization
      try {
        const existingPayload = await readMainPayload();
        if (existingPayload) {
          // Restore admin password if not updated
          if (payload.adminUser) {
            payload.adminUser.password = payload.adminUser.password || existingPayload.adminUser?.password;
          } else if (existingPayload.adminUser) {
            payload.adminUser = existingPayload.adminUser;
          }
          
          // Restore teacher passwords if not updated
          if (Array.isArray(payload.teachers) && Array.isArray(existingPayload.teachers)) {
            payload.teachers = payload.teachers.map(t => {
              const old = existingPayload.teachers.find(ot => ot.code === t.code);
              if (old && old.password && !t.password) {
                t.password = old.password;
              }
              return t;
            });
          }
        }
      } catch (e) {
        console.warn("Could not merge passwords on save:", e);
      }

      // --- RELATIONAL NORMALIZATION ---
      // Extract master data arrays and save them into individual tables
      const { majors, classes, rooms, teachers, subjects, students, ...restPayload } = payload;
      
      const saveToTable = async (tableName, items, idKey = 'id') => {
        if (!Array.isArray(items)) return;
        const client = await dbPool.connect();
        try {
          await client.query('BEGIN');
          await client.query(`DELETE FROM ${tableName}`);
          for (const item of items) {
            const rowId = String(item[idKey] || Math.random().toString(36).substring(7));
            await client.query(`INSERT INTO ${tableName} (id, payload) VALUES ($1, $2)`, [rowId, JSON.stringify(item)]);
          }
          await client.query('COMMIT');
        } catch (e) {
          await client.query('ROLLBACK');
          console.error(`Failed to save ${tableName}:`, e);
        } finally {
          client.release();
        }
      };

      await Promise.all([
        saveToTable('mst_majors', majors, 'name'),
        saveToTable('mst_classes', classes, 'name'),
        saveToTable('mst_rooms', rooms, 'id'),
        saveToTable('mst_teachers', teachers, 'code'),
        saveToTable('mst_subjects', subjects, 'id'),
        saveToTable('mst_students', students, 'nis'),
        saveToTable('mst_staffs', payload.staffs || [], 'staff_code')
      ]);

      // Save the rest of the config back to app_data
      const dataString = JSON.stringify(restPayload);
      await dbPool.query(`
        INSERT INTO app_data (store_key, data) VALUES ('main_store', $1)
        ON CONFLICT (store_key) DO UPDATE SET data = EXCLUDED.data, updated_at = CURRENT_TIMESTAMP
      `, [dataString]);
      
      // Trigger background sync for modules
      syncAllUsersToModules().catch(console.error);
      const session = getSession(req);
      if (session) {
        try {
          await dbPool.query(
            "INSERT INTO audit_logs (user_id, user_name, user_role, action, target_type, detail) VALUES ($1, $2, $3, $4, $5, $6)",
            [session.username || session.id || "admin", session.username || "Admin", session.role || "admin", "UPDATE", "system_data", "Menyimpan pembaruan data sistem (jadwal, guru, siswa, kelas, dll)"]
          );
        } catch (err) { console.error(err); }
      }
      
      send(req, res, 200, { ok: true });
    } catch (err) {
      console.error("Save Data Error:", err);
      sendDatabaseError(req, res, err);
    }
    return true;
  }

  return false;
}
